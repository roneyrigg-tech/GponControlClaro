# Control GPON — App de inventario, OTs y facturación

App móvil para técnico de instalación de fibra óptica (GPON/DGPON).
Permite:

- Leer una Orden de Trabajo (OT) copiada al portapapeles desde el sistema
  de despacho, y extraer automáticamente sus datos.
- Llevar un inventario local de materiales, con alertas cuando un
  material cae por debajo del stock mínimo.
- Calcular la mano de obra a facturar por cada OT, combinando la tarifa
  base del combo instalado (One/Two/Triple Play) más los adicionales
  medidos (metros extra de cable, equipos adicionales, etc.)
- Ver un reporte "Por Facturar" con el total acumulado pendiente de
  cobro, filtrable por semana, mes, o todo el historial.

Todos los datos se guardan **localmente en el celular** (SQLite), sin
necesidad de servidor ni conexión a internet para el uso diario.

## Cómo conseguir el APK instalable (sin instalar nada en tu compu)

Este proyecto está configurado para compilarse automáticamente en la
nube usando GitHub Actions. Cada vez que se sube o cambia código en la
rama `main`, un robot compila el APK y lo deja listo para descargar.

### Pasos para descargar el APK ya compilado

1. Entrá al repositorio en GitHub, en el navegador del celular o la compu.
2. Tocá la pestaña **"Actions"** (arriba, junto a "Code" y "Pull requests").
3. Vas a ver una lista de ejecuciones. Tocá la más reciente (la de
   arriba) que tenga un ✓ verde.
4. Bajá hasta la sección **"Artifacts"**.
5. Tocá **"gpon-control-apk"** para descargarlo. Es un archivo .zip que
   contiene el .apk adentro.
6. Descomprimí el .zip (en el celular, cualquier explorador de archivos
   moderno puede hacerlo) y vas a tener `app-debug.apk`.
7. Tocá el .apk para instalarlo. Android puede pedirte permiso para
   "instalar apps de fuentes desconocidas" — esto es normal porque la
   app no viene de Google Play, simplemente confirmá el permiso.

### Si querés forzar una nueva compilación manualmente

1. Pestaña **"Actions"**.
2. A la izquierda, tocá **"Compilar APK"**.
3. Botón **"Run workflow"** (arriba a la derecha de la lista) → "Run workflow".
4. Esperá unos minutos (típicamente 3-8 min) y refrescá la página.

## Estructura del proyecto

```
lib/
  models/          Modelos de datos (OT, Tarifa, Artículo de inventario)
  services/        Lógica de negocio, base de datos, providers de estado
  screens/         Pantallas de la app
android/           Configuración nativa de Android
.github/workflows/ Configuración de compilación automática en la nube
```

## Estado actual / pendientes conocidos

- **Tarifario**: cargado con los valores fotografiados de la tabla
  oficial de CARSO (21/06/2026). Si CARSO actualiza precios, hay que
  editar `lib/models/tarifa.dart`.
- **Inventario**: carga manual por ahora. El parseo automático del PDF
  de despacho de CARSO queda pendiente — se necesita un PDF real (no
  una foto) para confirmar el formato exacto de columnas y el
  significado de los signos +/- antes de automatizarlo con seguridad.
- **Backup a Google Drive**: no implementado todavía en esta primera
  versión. Se puede agregar en una iteración futura.
- **Reportes PDF/CSV**: las librerías (`pdf`, `csv`, `share_plus`) ya
  están en las dependencias, pero la generación de reportes exportables
  todavía no tiene pantalla propia — por ahora "Por Facturar" se ve
  solo dentro de la app.
