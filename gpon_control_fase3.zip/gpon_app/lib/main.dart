// lib/main.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'services/ot_provider.dart';
import 'services/inventario_provider.dart';
import 'services/configuracion_provider.dart';
import 'services/notificacion_service.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificacionService.instance.inicializar();
  runApp(const GponControlApp());
}

class GponControlApp extends StatelessWidget {
  const GponControlApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => OTProvider()..cargar()),
        ChangeNotifierProvider(create: (_) => InventarioProvider()..cargar()),
        ChangeNotifierProvider(create: (_) => ConfiguracionProvider()..cargar()),
      ],
      child: MaterialApp(
        title: 'Control GPON',
        debugShowCheckedModeBanner: false,
        theme: _buildTheme(),
        home: const HomeScreen(),
      ),
    );
  }

  ThemeData _buildTheme() {
    // Paleta de alto contraste pensada para uso en exteriores (sol
    // directo), según lo pedido: interfaz limpia y de rápida navegación.
    const azulSenal = Color(0xFF0B5FFF);
    const naranjaAlerta = Color(0xFFE8531C);
    const fondo = Color(0xFFF5F6F8);

    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: fondo,
      colorScheme: ColorScheme.fromSeed(
        seedColor: azulSenal,
        primary: azulSenal,
        error: naranjaAlerta,
        brightness: Brightness.light,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF14213D),
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        elevation: 1,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 0),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
        ),
      ),
      textTheme: const TextTheme(
        titleLarge: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        titleMedium: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
        bodyLarge: TextStyle(fontSize: 15),
      ),
    );
  }
}
