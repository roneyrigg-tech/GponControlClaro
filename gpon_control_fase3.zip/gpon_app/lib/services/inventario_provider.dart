// lib/services/inventario_provider.dart
//
// FASE 2 (25/06/2026): se agrega gestión de equipos seriados
// (EquipoSeriado: ONT, MESH, STB rastreados por número de serie
// individual) y herramientas (chequeo mensual), además de lo que ya
// existía para consumibles.

import 'package:flutter/foundation.dart';
import '../models/articulo_inventario.dart';
import 'database_service.dart';
import 'notificacion_service.dart';

class InventarioProvider extends ChangeNotifier {
  List<ArticuloInventario> _articulos = [];
  List<EquipoSeriado> _equipos = [];
  List<Herramienta> _herramientas = [];
  bool _cargando = false;

  List<ArticuloInventario> get articulos => _articulos;
  List<EquipoSeriado> get equipos => _equipos;
  List<Herramienta> get herramientas => _herramientas;
  bool get cargando => _cargando;

  List<ArticuloInventario> get enAlerta =>
      _articulos.where((a) => a.enAlertaCritica).toList();

  /// Equipos seriados disponibles (en la mochila del técnico, listos
  /// para instalar), opcionalmente filtrados por contratista y/o tipo.
  List<EquipoSeriado> equiposDisponibles({String? contratistaId, String? tipoEquipo}) {
    return _equipos.where((e) {
      if (e.estado != EstadoEquipoSeriado.disponible) return false;
      if (contratistaId != null && e.contratistaId != contratistaId) return false;
      if (tipoEquipo != null && e.tipoEquipo != tipoEquipo) return false;
      return true;
    }).toList();
  }

  Future<void> cargar() async {
    _cargando = true;
    notifyListeners();
    _articulos = await DatabaseService.instance.obtenerInventario();
    _equipos = await DatabaseService.instance.obtenerEquiposSeriados();
    _herramientas = await DatabaseService.instance.obtenerHerramientas();
    _cargando = false;
    notifyListeners();
  }

  Future<void> guardarArticulo(ArticuloInventario articulo) async {
    await DatabaseService.instance.upsertArticulo(articulo);
    await cargar();
  }

  Future<void> eliminarArticulo(String id) async {
    await DatabaseService.instance.eliminarArticulo(id);
    await cargar();
  }

  /// Descuenta material consumido en una OT y evalúa si cae en alerta
  /// crítica, disparando notificación local si corresponde.
  Future<void> descontarPorConsumo(
    String articuloId,
    double cantidad,
    String otId,
  ) async {
    await DatabaseService.instance
        .descontarInventario(articuloId, cantidad, otId);
    await cargar();

    final articulo = _articulos.firstWhere(
      (a) => a.id == articuloId,
      orElse: () => ArticuloInventario(
        id: '',
        codigo: '',
        nombre: '',
        cantidadDisponible: 0,
        stockMinimo: 0,
        unidad: '',
      ),
    );

    if (articulo.id.isNotEmpty && articulo.enAlertaCritica) {
      await NotificacionService.instance.mostrarAlertaStock(articulo);
    }
  }

  // ---------------- EQUIPOS SERIADOS ----------------

  Future<void> agregarEquipoSeriado(EquipoSeriado equipo) async {
    await DatabaseService.instance.upsertEquipoSeriado(equipo);
    await cargar();
  }

  Future<void> agregarEquiposSeriados(List<EquipoSeriado> equipos) async {
    for (final e in equipos) {
      await DatabaseService.instance.upsertEquipoSeriado(e);
    }
    await cargar();
  }

  /// Marca un equipo como instalado en una OT (lo sacó de "disponible").
  Future<void> marcarInstalado(String equipoId, String otId) async {
    final equipo = _equipos.firstWhere((e) => e.id == equipoId);
    equipo.estado = EstadoEquipoSeriado.instalado;
    equipo.otIdInstalado = otId;
    await DatabaseService.instance.upsertEquipoSeriado(equipo);
    await cargar();
  }

  /// Devuelve un equipo a "disponible" (cambio en sitio: el equipo no
  /// estaba realmente averiado, vuelve a la mochila del técnico).
  Future<void> devolverADisponible(String contratistaId, String tipoEquipo, String serie) async {
    final id = serie; // EquipoSeriado.id == serie
    final existente = _equipos.where((e) => e.id == id).toList();

    if (existente.isEmpty) {
      // El equipo no estaba registrado todavía en este inventario (pudo
      // haber llegado directo de bodega sin pasar por el flujo de OCR).
      // Se crea la fila como disponible para no perder la trazabilidad.
      await DatabaseService.instance.upsertEquipoSeriado(EquipoSeriado(
        id: id,
        contratistaId: contratistaId,
        tipoEquipo: tipoEquipo,
        serie: serie,
        estado: EstadoEquipoSeriado.disponible,
      ));
    } else {
      final equipo = existente.first;
      equipo.estado = EstadoEquipoSeriado.disponible;
      equipo.otIdInstalado = null;
      await DatabaseService.instance.upsertEquipoSeriado(equipo);
    }
    await cargar();
  }

  /// Marca un equipo como dañado (avería real: sale de circulación
  /// hasta que se devuelva físicamente a bodega).
  Future<void> marcarDanado(String contratistaId, String tipoEquipo, String serie) async {
    final id = serie;
    final existente = _equipos.where((e) => e.id == id).toList();

    if (existente.isEmpty) {
      await DatabaseService.instance.upsertEquipoSeriado(EquipoSeriado(
        id: id,
        contratistaId: contratistaId,
        tipoEquipo: tipoEquipo,
        serie: serie,
        estado: EstadoEquipoSeriado.danado,
      ));
    } else {
      final equipo = existente.first;
      equipo.estado = EstadoEquipoSeriado.danado;
      await DatabaseService.instance.upsertEquipoSeriado(equipo);
    }
    await cargar();
  }

  // ---------------- HERRAMIENTAS ----------------

  /// Guarda la herramienta y (re)programa su recordatorio mensual de
  /// chequeo a partir de la fecha de último chequeo (o de hoy, si es
  /// nueva o nunca se chequeó).
  Future<void> guardarHerramienta(Herramienta herramienta) async {
    await DatabaseService.instance.upsertHerramienta(herramienta);
    await NotificacionService.instance.programarChequeoMensual(
      herramientaId: herramienta.id,
      nombreHerramienta: herramienta.nombre,
      desde: herramienta.ultimoChequeo ?? DateTime.now(),
    );
    await cargar();
  }
}
