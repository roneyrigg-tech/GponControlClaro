// lib/services/ocr_service.dart
//
// FASE 2 (25/06/2026): servicio de OCR on-device (Google ML Kit) para
// leer la hoja de "Recibo de Entrega de Materiales" que bodega entrega
// en papel (ver foto de COLSAGO, 22/06/2026, y la de CARSO con
// estructura similar pero distinto formato exacto de columnas).
//
// IMPORTANTE: el OCR es una AYUDA para llenar el formulario más rápido,
// no una fuente de verdad. ML Kit reconoce bien texto impreso pero
// comete errores con tablas (columnas mal alineadas, números pegados
// al texto vecino, series largas cortadas). Por eso el resultado de
// este servicio SIEMPRE se muestra en una pantalla de confirmación
// donde el técnico corrige antes de aplicar al inventario — nunca se
// escribe directo a la base de datos desde aquí.
//
// Estrategia de reconocimiento de filas (heurística, no exacta):
//   - ML Kit devuelve bloques de texto con sus líneas. Cada línea de la
//     hoja real corresponde, casi siempre, a una fila de la tabla.
//   - Una serie (columna SERIES) es un token alfanumérico largo (>= 8
//     caracteres, mezcla de letras y números) que aparece AL INICIO de
//     la línea, antes de la descripción. Si no hay token así, la fila
//     es un consumible sin serie.
//   - La cantidad es el último número entero/decimal "suelto" de la
//     línea (no pegado a letras), normalmente después de la
//     descripción y antes de la columna de estado/observaciones.
//   - El tipo de equipo (ONT, MESH, STB/STBS) se reconoce por palabra
//     completa dentro de la descripción cuando hay serie.
//
// Esta heurística no será perfecta con manuscritos ni con fotos
// torcidas/borrosas — de ahí la pantalla de confirmación obligatoria.

import 'dart:io';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// Una fila candidata extraída de la hoja, antes de confirmar.
class FilaOCRCandidata {
  String descripcion;
  double? cantidad;
  String? serie; // null si es un consumible sin número de serie
  String? tipoEquipo; // 'ONT', 'MESH', 'STB' — solo si serie != null
  bool seleccionada; // el técnico puede destildar filas mal leídas

  FilaOCRCandidata({
    required this.descripcion,
    this.cantidad,
    this.serie,
    this.tipoEquipo,
    this.seleccionada = true,
  });

  bool get esSeriado => serie != null && serie!.isNotEmpty;
}

class OCRService {
  static final TextRecognizer _recognizer =
      TextRecognizer(script: TextRecognitionScript.latin);

  /// Reconoce el texto crudo de una imagen. Devuelve todas las líneas
  /// detectadas, en el orden en que ML Kit las agrupa por bloque.
  static Future<List<String>> reconocerLineas(String rutaImagen) async {
    final inputImage = InputImage.fromFile(File(rutaImagen));
    final resultado = await _recognizer.processImage(inputImage);

    final lineas = <String>[];
    for (final bloque in resultado.blocks) {
      for (final linea in bloque.lines) {
        final texto = linea.text.trim();
        if (texto.isNotEmpty) lineas.add(texto);
      }
    }
    return lineas;
  }

  /// Reconoce el texto de la imagen y lo interpreta como filas de la
  /// hoja de materiales (consumibles y equipos seriados mezclados).
  /// Devuelve una lista de candidatas para que el técnico confirme o
  /// corrija — nunca se aplica directamente al inventario.
  static Future<List<FilaOCRCandidata>> reconocerHojaMateriales(
      String rutaImagen) async {
    final lineas = await reconocerLineas(rutaImagen);
    return _interpretarLineas(lineas);
  }

  /// Libera los recursos del reconocedor. Llamar cuando la app cierre
  /// la pantalla de captura, para no dejar el motor de OCR cargado en
  /// memoria innecesariamente.
  static Future<void> cerrar() => _recognizer.close();

  // ---------------- Heurística de interpretación ----------------

  static final RegExp _patronSerie = RegExp(r'^[A-Z0-9]{8,}$');
  static final RegExp _patronNumero = RegExp(r'^\d+([.,]\d+)?$');

  // Palabras que marcan el INICIO de la columna "Estado/Observaciones"
  // en la hoja real (ej. "RECIBIDO EN ETA", más el nombre de quien
  // recibió el ítem, como "bodega", "harold", "kevin"). Todo lo que
  // venga a partir de la primera coincidencia de estas palabras se
  // descarta — no es ni cantidad ni parte de la descripción del
  // material. Esto evita que la heurística de cantidad agarre un
  // número equivocado más adelante en la línea, y evita que nombres
  // de quien recibió terminen pegados a la descripción.
  static const List<String> _palabrasEstado = ['recibido', 'pendiente', 'rechazado'];

  static List<FilaOCRCandidata> _interpretarLineas(List<String> lineas) {
    final filas = <FilaOCRCandidata>[];

    // Palabras que son encabezados de la tabla o del documento, no
    // filas de material — se descartan si una línea coincide casi
    // exactamente con alguna de ellas.
    const encabezadosConocidos = {
      'series',
      'descripción del material',
      'descripcion del material',
      'cantidad',
      'estado / observaciones',
      'estado/observaciones',
      'recibo de entrega de materiales',
      'detalle del material',
      'datos de las partes',
    };

    for (final lineaOriginal in lineas) {
      final linea = lineaOriginal.trim();
      if (linea.isEmpty) continue;
      if (encabezadosConocidos.contains(linea.toLowerCase())) continue;

      var tokens = linea.split(RegExp(r'\s+'));
      if (tokens.isEmpty) continue;

      // Cortar la línea en la primera palabra de estado conocida: todo
      // lo que sigue (incluyendo esa palabra) es la columna de
      // Estado/Observaciones, no material ni cantidad.
      final indiceEstado = tokens.indexWhere(
          (t) => _palabrasEstado.contains(t.toLowerCase()));
      if (indiceEstado != -1) {
        tokens = tokens.sublist(0, indiceEstado);
      }
      if (tokens.isEmpty) continue;

      String? serie;
      String? tipoEquipo;
      double? cantidad;
      final descripcionTokens = <String>[];

      // 1) ¿El primer token es una serie? (alfanumérico largo, sin
      // espacios, típico de ONT/MESH/STB: ej. "4857544374B9D1B4").
      final primerToken = tokens.first.toUpperCase();
      if (_patronSerie.hasMatch(primerToken) &&
          RegExp(r'[A-Z]').hasMatch(primerToken) &&
          RegExp(r'[0-9]').hasMatch(primerToken)) {
        serie = primerToken;
      }

      // 2) Recorrer el resto de tokens. La cantidad es el ÚLTIMO token
      // de la línea (ya recortada antes de la columna de estado): en
      // la hoja real, Cantidad es la columna justo antes de Estado, así
      // que tras cortar en "recibido/pendiente/..." el último token
      // restante es la cantidad. Esto evita confundir números que son
      // parte del nombre del material (ej. "RJ 45", donde 45 NO es la
      // última posición real de cantidad porque a veces el material
      // trae su propio número en el nombre antes del valor de cantidad
      // real — ver nota más abajo).
      final inicioResto = serie != null ? 1 : 0;
      final restoTokens = tokens.sublist(inicioResto);

      if (serie != null) {
        // Para equipos seriados: buscar el tipo de equipo conocido en
        // cualquier posición restante; el resto (si queda algo) se
        // ignora como descripción, porque el nombre real es el tipo de
        // equipo (ONT/MESH/STB), no texto libre.
        for (final t in restoTokens) {
          final tUpper = t.toUpperCase().replaceAll(RegExp(r'[^A-Z]'), '');
          if (tUpper == 'ONT' || tUpper == 'MESH' || tUpper == 'STB' || tUpper == 'STBS') {
            tipoEquipo = tUpper == 'STBS' ? 'STB' : tUpper;
            break;
          }
        }
        cantidad = 1; // un equipo seriado siempre es 1 unidad física
      } else if (restoTokens.isNotEmpty &&
          _patronNumero.hasMatch(restoTokens.last.replaceAll(',', '.'))) {
        // Consumible: el último token restante (justo antes de donde
        // empezaba la columna de estado) es la cantidad real.
        cantidad = double.tryParse(restoTokens.last.replaceAll(',', '.'));
        descripcionTokens.addAll(restoTokens.sublist(0, restoTokens.length - 1));
      } else {
        // No se encontró un número al final: toda la línea restante es
        // descripción, y la cantidad queda pendiente de que el técnico
        // la complete a mano en la pantalla de confirmación.
        descripcionTokens.addAll(restoTokens);
      }

      final descripcion = descripcionTokens.join(' ').trim();
      if (descripcion.isEmpty && serie == null) continue; // línea inútil

      filas.add(FilaOCRCandidata(
        descripcion: descripcion.isNotEmpty
            ? descripcion
            : (tipoEquipo ?? 'EQUIPO SIN DESCRIPCIÓN'),
        cantidad: cantidad,
        serie: serie,
        tipoEquipo: tipoEquipo,
      ));
    }

    return filas;
  }
}
