// lib/services/notificacion_service.dart
//
// Notificaciones locales para alertas de material crítico bajo.
//
// FASE 2 (25/06/2026): se agrega notificación PROGRAMADA para el
// chequeo mensual de herramientas (zonedSchedule), además de las
// notificaciones inmediatas de stock crítico que ya existían.
// zonedSchedule necesita saber la zona horaria del dispositivo, así
// que se inicializa con flutter_timezone (Costa Rica: America/Costa_Rica).

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:flutter_timezone/flutter_timezone.dart';
import '../models/articulo_inventario.dart';

class NotificacionService {
  static final NotificacionService instance = NotificacionService._internal();
  NotificacionService._internal();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _inicializado = false;

  Future<void> inicializar() async {
    if (_inicializado) return;

    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: androidSettings);

    await _plugin.initialize(settings);

    // Inicializa la base de datos de zonas horarias y fija la zona
    // local real del dispositivo (necesario para que zonedSchedule
    // dispare a la hora correcta, no en UTC).
    tzdata.initializeTimeZones();
    try {
      final nombreZona = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(nombreZona));
    } catch (_) {
      // Si por algún motivo no se puede leer la zona del dispositivo,
      // se usa Costa Rica como respaldo (zona donde opera el técnico).
      tz.setLocalLocation(tz.getLocation('America/Costa_Rica'));
    }

    _inicializado = true;
  }

  Future<void> mostrarAlertaStock(ArticuloInventario articulo) async {
    await inicializar();

    const androidDetails = AndroidNotificationDetails(
      'stock_critico_channel',
      'Alertas de stock crítico',
      channelDescription:
          'Notifica cuando un material cae por debajo del stock mínimo',
      importance: Importance.high,
      priority: Priority.high,
    );
    const details = NotificationDetails(android: androidDetails);

    await _plugin.show(
      articulo.id.hashCode,
      '⚠️ Material crítico bajo',
      '${articulo.nombre}: quedan ${articulo.cantidadDisponible.toStringAsFixed(1)} ${articulo.unidad} '
          '(mínimo ${articulo.stockMinimo.toStringAsFixed(1)})',
      details,
    );
  }

  /// Programa el recordatorio mensual de chequeo de una herramienta,
  /// a partir de la fecha de su último chequeo (o de hoy, si nunca se
  /// chequeó). Si ya había un recordatorio programado para esa misma
  /// herramienta, lo reemplaza (mismo id de notificación = mismo hash
  /// del id de la herramienta).
  Future<void> programarChequeoMensual({
    required String herramientaId,
    required String nombreHerramienta,
    required DateTime desde,
  }) async {
    await inicializar();

    const androidDetails = AndroidNotificationDetails(
      'chequeo_herramientas_channel',
      'Chequeo mensual de herramientas',
      channelDescription:
          'Recuerda revisar el estado de las herramientas entregadas una vez al mes',
      importance: Importance.high,
      priority: Priority.high,
    );
    const details = NotificationDetails(android: androidDetails);

    final proximaFecha = desde.add(const Duration(days: 30));
    final fechaProgramada = tz.TZDateTime(
      tz.local,
      proximaFecha.year,
      proximaFecha.month,
      proximaFecha.day,
      8, // 8:00 a.m., antes de salir a trabajar
    );

    await _plugin.zonedSchedule(
      herramientaId.hashCode,
      '🔧 Chequeo mensual de herramientas',
      'Es hora de revisar "$nombreHerramienta".',
      fechaProgramada,
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
    );
  }

  /// Cancela el recordatorio programado de una herramienta (ej. si se
  /// elimina del inventario).
  Future<void> cancelarChequeoMensual(String herramientaId) async {
    await _plugin.cancel(herramientaId.hashCode);
  }
}
