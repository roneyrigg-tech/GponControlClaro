// lib/services/quincena_service.dart
//
// FASE 3 (26/06/2026): cálculo de los períodos de facturación
// quincenal (días hábiles 15 y 30/último día del mes), aplicando la
// regla confirmada por Roney:
//
//   - El cierre normal es el día 15 y el día 30 de cada mes.
//   - Si esa fecha NO es día hábil (cae sábado, domingo, o feriado de
//     Costa Rica), el cierre se corre al día hábil ANTERIOR más
//     cercano (no al siguiente).
//   - Para el cierre de "fin de mes", si el mes no tiene día 30 (ej.
//     febrero) o tiene 31, se usa el ÚLTIMO DÍA REAL del mes como
//     fecha base antes de aplicar la regla de día hábil — no se
//     fuerza siempre el número 30.
//
// Depende de la tabla de feriados (ver feriado.dart / DatabaseService)
// para saber qué fechas excluir además de sábados y domingos.

import '../models/feriado.dart';

class PeriodoQuincena {
  final DateTime inicio; // primer día del período (inclusive)
  final DateTime fin; // fecha de cierre real, ya ajustada a día hábil
  final DateTime
      fechaNominal; // la fecha "ideal" sin ajustar (15 o 30), para mostrarla junto al cierre real si difieren

  PeriodoQuincena({
    required this.inicio,
    required this.fin,
    required this.fechaNominal,
  });

  bool get seAjustoPorDiaInhabil =>
      fin.year != fechaNominal.year ||
      fin.month != fechaNominal.month ||
      fin.day != fechaNominal.day;
}

class QuincenaService {
  /// Determina si una fecha es día hábil: no es sábado, no es domingo,
  /// y no está en la lista de feriados.
  static bool esDiaHabil(DateTime fecha, List<Feriado> feriados) {
    final esFinDeSemana =
        fecha.weekday == DateTime.saturday || fecha.weekday == DateTime.sunday;
    if (esFinDeSemana) return false;

    final esFeriado = feriados.any((f) =>
        f.fecha.year == fecha.year &&
        f.fecha.month == fecha.month &&
        f.fecha.day == fecha.day);
    return !esFeriado;
  }

  /// Retrocede desde [fecha] hasta encontrar el día hábil más cercano
  /// (incluyendo la fecha misma si ya es hábil). Nunca avanza hacia
  /// adelante — Roney confirmó que el ajuste es siempre hacia atrás.
  static DateTime diaHabilAnteriorOMismo(DateTime fecha, List<Feriado> feriados) {
    var candidata = fecha;
    while (!esDiaHabil(candidata, feriados)) {
      candidata = candidata.subtract(const Duration(days: 1));
    }
    return candidata;
  }

  static int _ultimoDiaDelMes(int year, int month) {
    // Truco estándar: el día 0 del mes siguiente es el último día del
    // mes actual.
    final primerDiaSiguiente = DateTime(year, month + 1, 1);
    final ultimoDiaActual = primerDiaSiguiente.subtract(const Duration(days: 1));
    return ultimoDiaActual.day;
  }

  /// Calcula los DOS períodos de quincena de un mes/año dado:
  ///   1. Del 1 al 15 (cierre nominal: día 15).
  ///   2. Del 16 al último día del mes (cierre nominal: día 30, o el
  ///      último día real si el mes no tiene 30, ej. febrero).
  /// Cada cierre se ajusta hacia atrás al día hábil más cercano si la
  /// fecha nominal no es hábil.
  static List<PeriodoQuincena> calcularPeriodosDelMes(
      int year, int month, List<Feriado> feriados) {
    final ultimoDia = _ultimoDiaDelMes(year, month);

    final cierreNominal1 = DateTime(year, month, 15);
    final cierreReal1 = diaHabilAnteriorOMismo(cierreNominal1, feriados);

    // Cierre nominal de la segunda quincena: día 30, o el último día
    // real del mes si tiene menos de 30 (febrero) — nunca un día que
    // no existe en el mes.
    final diaNominal2 = ultimoDia < 30 ? ultimoDia : 30;
    final cierreNominal2 = DateTime(year, month, diaNominal2);
    // Si el mes tiene 31 días, el cierre de la "segunda quincena" sigue
    // siendo conceptualmente el 30, pero el período de facturación debe
    // cubrir hasta el último día real (31) para no dejar el día 31 sin
    // facturar. Por eso el FIN DEL PERÍODO usa el último día real,
    // mientras que el CIERRE (fecha en que se hace el corte/factura)
    // respeta la regla de Roney del día 30 ajustado a hábil.
    final cierreReal2 = diaHabilAnteriorOMismo(cierreNominal2, feriados);

    return [
      PeriodoQuincena(
        inicio: DateTime(year, month, 1),
        fin: cierreReal1,
        fechaNominal: cierreNominal1,
      ),
      PeriodoQuincena(
        inicio: DateTime(year, month, 16),
        fin: DateTime(year, month, ultimoDia), // cubre hasta el día 31 si existe
        fechaNominal: cierreNominal2,
      ),
    ];
  }

  /// Dada una fecha cualquiera (normalmente "hoy"), determina a cuál de
  /// los dos períodos de quincena pertenece, dentro del mes de esa
  /// fecha. Útil para que la pantalla de facturación sugiera el
  /// período actual sin que el técnico tenga que calcularlo a mano.
  static PeriodoQuincena periodoQueContiene(
      DateTime fecha, List<Feriado> feriados) {
    final periodos = calcularPeriodosDelMes(fecha.year, fecha.month, feriados);
    if (fecha.day <= 15) return periodos[0];
    return periodos[1];
  }

  /// Fecha de cierre EFECTIVA para mostrar al técnico cuándo debe
  /// elaborar/enviar la factura de un período (es la misma que
  /// PeriodoQuincena.fin, expuesta acá para conveniencia y claridad de
  /// nombre cuando se usa fuera de este servicio).
  static DateTime fechaDeCierre(PeriodoQuincena periodo) => periodo.fin;
}
