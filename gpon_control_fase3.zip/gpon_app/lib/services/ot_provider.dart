// lib/services/ot_provider.dart
//
// Provider (ChangeNotifier) que mantiene en memoria la lista de OTs
// y notifica a la UI cuando cambia.

import 'package:flutter/foundation.dart';
import '../models/orden_trabajo.dart';
import 'database_service.dart';

class OTProvider extends ChangeNotifier {
  List<OrdenTrabajo> _ordenes = [];
  bool _cargando = false;

  List<OrdenTrabajo> get ordenes => _ordenes;
  bool get cargando => _cargando;

  List<OrdenTrabajo> ordenesPorEstado(EstadoOT estado) =>
      _ordenes.where((o) => o.estadoFlujo == estado).toList();

  Future<void> cargar() async {
    _cargando = true;
    notifyListeners();
    _ordenes = await DatabaseService.instance.obtenerOrdenes();
    _cargando = false;
    notifyListeners();
  }

  /// Parsea el texto copiado de Oracle y lo guarda como nueva OT.
  ///
  /// [contratistaId] indica de qué contratista es la OT ('carso' o
  /// 'colsago'). Por defecto 'carso' si no se especifica (ver
  /// OTParser.parse), porque el texto de Oracle no identifica el
  /// contratista de forma confiable — el técnico lo elige en la UI
  /// antes de pegar el texto.
  Future<bool> agregarDesdeTexto(String texto, {String contratistaId = 'carso'}) async {
    final ot = OTParser.parse(texto, contratistaId: contratistaId);
    if (ot == null) return false;

    // Evitar duplicados: si ya existe esa OT, no la sobreescribimos
    // sin avisar (se podría perder estado de avance ya registrado).
    final existente = _ordenes.where((o) => o.id == ot.id).toList();
    if (existente.isNotEmpty) {
      return false;
    }

    await DatabaseService.instance.upsertOT(ot);
    await cargar();
    return true;
  }

  Future<void> actualizarEstado(String otId, EstadoOT nuevoEstado) async {
    final ot = _ordenes.firstWhere((o) => o.id == otId);
    ot.estadoFlujo = nuevoEstado;
    await DatabaseService.instance.upsertOT(ot);
    await cargar();
  }

  Future<void> guardar(OrdenTrabajo ot) async {
    await DatabaseService.instance.upsertOT(ot);
    await cargar();
  }

  Future<void> eliminar(String id) async {
    await DatabaseService.instance.eliminarOT(id);
    await cargar();
  }
}
