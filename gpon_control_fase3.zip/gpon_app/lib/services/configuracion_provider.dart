// lib/services/configuracion_provider.dart
//
// FASE 3 (26/06/2026): provider para la configuración de la app que no
// cambia todos los días — contratistas (cada uno con su propio
// tarifario independiente, ver tarifa.dart) y feriados de Costa Rica
// (lista fija editable, usada por QuincenaService para el cierre de
// quincena). Se agrupan en un provider separado de OTProvider e
// InventarioProvider porque son datos de configuración, no de trabajo
// diario.

import 'package:flutter/foundation.dart';
import '../models/contratista.dart';
import '../models/feriado.dart';
import 'database_service.dart';

class ConfiguracionProvider extends ChangeNotifier {
  List<Contratista> _contratistas = [];
  List<Feriado> _feriados = [];
  bool _cargando = false;

  List<Contratista> get contratistas => _contratistas;
  List<Feriado> get feriados => _feriados;
  bool get cargando => _cargando;

  Future<void> cargar() async {
    _cargando = true;
    notifyListeners();
    _contratistas = await DatabaseService.instance.obtenerContratistas();
    _feriados = await DatabaseService.instance.obtenerFeriados();
    _cargando = false;
    notifyListeners();
  }

  // ---------------- CONTRATISTAS ----------------

  /// Agrega una contrata nueva. El id se genera a partir del nombre
  /// (minúsculas, sin espacios/acentos) para mantener el mismo patrón
  /// que 'carso'/'colsago'. Su tarifario queda vacío hasta que se
  /// cargue manualmente — ver nota en tarifa.dart sobre tarifarioDe().
  Future<void> agregarContratista({
    required String nombre,
    required String razonSocial,
    String? cedulaJuridica,
  }) async {
    final id = _generarId(nombre);
    final contratista = Contratista(
      id: id,
      nombre: nombre,
      razonSocial: razonSocial,
      cedulaJuridica: cedulaJuridica,
      tarifarioVigenteDesde: DateTime.now(),
    );
    await DatabaseService.instance.upsertContratista(contratista);
    await cargar();
  }

  Future<void> actualizarContratista(Contratista contratista) async {
    await DatabaseService.instance.upsertContratista(contratista);
    await cargar();
  }

  String _generarId(String nombre) {
    final base = nombre
        .toLowerCase()
        .replaceAll(RegExp(r'[áàä]'), 'a')
        .replaceAll(RegExp(r'[éèë]'), 'e')
        .replaceAll(RegExp(r'[íìï]'), 'i')
        .replaceAll(RegExp(r'[óòö]'), 'o')
        .replaceAll(RegExp(r'[úùü]'), 'u')
        .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
        .replaceAll(RegExp(r'^_+|_+$'), '');
    // Evita colisión si ya existe un contratista con ese id (ej. dos
    // contratas con nombres muy parecidos).
    if (!_contratistas.any((c) => c.id == base)) return base;
    var sufijo = 2;
    while (_contratistas.any((c) => c.id == '${base}_$sufijo')) {
      sufijo++;
    }
    return '${base}_$sufijo';
  }

  // ---------------- FERIADOS ----------------

  Future<void> agregarFeriado(DateTime fecha, String nombre) async {
    await DatabaseService.instance.upsertFeriado(Feriado(fecha: fecha, nombre: nombre));
    await cargar();
  }

  Future<void> eliminarFeriado(String id) async {
    await DatabaseService.instance.eliminarFeriado(id);
    await cargar();
  }
}
