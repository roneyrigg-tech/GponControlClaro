// lib/services/database_service.dart
//
// Servicio central de base de datos local (SQLite vía sqflite).
// Toda la persistencia de la app pasa por aquí.
//
// FASE 1 (25/06/2026): se sube el esquema de version 1 a version 2
// para soportar multi-contratista y el log de equipos del formato
// extendido de Oracle.
//
// FASE 2 (25/06/2026): se sube a version 3 para soportar inventario
// por contratista (columnas contratistaId/tipo en inventario), equipos
// rastreados por número de serie individual (tabla equipos_seriados) y
// herramientas con chequeo mensual (tabla herramientas).
//
// FASE 3 (26/06/2026): se sube a version 4 para soportar:
//   - tarifarioVigenteDesde en contratistas (cada contratista vuelve a
//     tener su propio tarifario independiente, ver tarifa.dart).
//   - tabla feriados: lista fija de feriados de Costa Rica, editable
//     desde la app, usada para calcular el cierre de quincena (días
//     hábiles 15/30, corriendo al día hábil anterior si cae en fin de
//     semana o feriado).
//
// En todos los casos onUpgrade usa ALTER TABLE ADD COLUMN / CREATE
// TABLE IF NOT EXISTS (no borra ni recrea tablas) para no perder
// OTs/inventario ya guardados por versiones anteriores de la app.

import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/orden_trabajo.dart';
import '../models/articulo_inventario.dart';
import '../models/contratista.dart';
import '../models/feriado.dart';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._internal();
  DatabaseService._internal();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'gpon_control.db');

    return openDatabase(
      path,
      version: 4,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE inventario (
            id TEXT PRIMARY KEY,
            contratistaId TEXT,
            codigo TEXT,
            nombre TEXT,
            tipo TEXT,
            cantidadDisponible REAL,
            stockMinimo REAL,
            unidad TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE ordenes_trabajo (
            id TEXT PRIMARY KEY,
            numeroOT TEXT,
            contratistaId TEXT,
            canalVenta TEXT,
            nombreCliente TEXT,
            estadoTexto TEXT,
            estadoFlujo TEXT,
            tipoOT TEXT,
            subtipo TEXT,
            plan TEXT,
            etapaOrden TEXT,
            numeroSolicitud TEXT,
            numeroFacturacion TEXT,
            direccion TEXT,
            fechaCreacion TEXT,
            telefonoContacto TEXT,
            categorizacion TEXT,
            tipoOrden TEXT,
            tipoServicio TEXT,
            inicioFin TEXT,
            duracion TEXT,
            tarifaBaseId TEXT,
            materialesConsumidosJson TEXT,
            adicionalesFacturadosJson TEXT,
            logEquiposJson TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE liquidaciones (
            id TEXT PRIMARY KEY,
            otId TEXT,
            contratistaId TEXT,
            fecha TEXT,
            monto REAL,
            descripcion TEXT,
            facturada INTEGER
          )
        ''');

        await db.execute('''
          CREATE TABLE movimientos_inventario (
            id TEXT PRIMARY KEY,
            articuloId TEXT,
            fecha TEXT,
            cantidad REAL,
            tipo TEXT,
            otId TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE contratistas (
            id TEXT PRIMARY KEY,
            nombre TEXT,
            razonSocial TEXT,
            cedulaJuridica TEXT,
            tarifarioVigenteDesde TEXT,
            activo INTEGER
          )
        ''');

        await db.execute('''
          CREATE TABLE equipos_seriados (
            id TEXT PRIMARY KEY,
            contratistaId TEXT,
            tipoEquipo TEXT,
            serie TEXT,
            estado TEXT,
            otIdInstalado TEXT,
            fechaIngreso TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE herramientas (
            id TEXT PRIMARY KEY,
            contratistaId TEXT,
            nombre TEXT,
            estado TEXT,
            ultimoChequeo TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE feriados (
            id TEXT PRIMARY KEY,
            fecha TEXT,
            nombre TEXT
          )
        ''');

        // Precarga los contratistas conocidos (CARSO, COLSAGO) y los
        // feriados oficiales de Costa Rica en una instalación nueva.
        for (final c in contratistasIniciales) {
          await db.insert('contratistas', c.toMap());
        }
        for (final f in feriadosCostaRicaIniciales) {
          await db.insert('feriados', f.toMap());
        }
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          // Columnas nuevas en ordenes_trabajo. SQLite no permite
          // agregar varias columnas en un solo ALTER TABLE, así que se
          // hace una por una. Todas son nullable (sin NOT NULL) para
          // que las filas existentes no fallen al migrar.
          const columnasNuevas = [
            'contratistaId TEXT',
            'telefonoContacto TEXT',
            'categorizacion TEXT',
            'tipoOrden TEXT',
            'tipoServicio TEXT',
            'inicioFin TEXT',
            'duracion TEXT',
            'logEquiposJson TEXT',
          ];
          for (final columna in columnasNuevas) {
            await db.execute(
                'ALTER TABLE ordenes_trabajo ADD COLUMN $columna');
          }

          // Las OTs existentes (todas de antes de Fase 1) se asumen de
          // CARSO, que era el único contratista hasta ahora.
          await db.execute(
              "UPDATE ordenes_trabajo SET contratistaId = 'carso' WHERE contratistaId IS NULL");

          await db.execute('''
            CREATE TABLE IF NOT EXISTS contratistas (
              id TEXT PRIMARY KEY,
              nombre TEXT,
              razonSocial TEXT,
              cedulaJuridica TEXT,
              activo INTEGER
            )
          ''');

          for (final c in contratistasIniciales) {
            await db.insert(
              'contratistas',
              c.toMap(),
              conflictAlgorithm: ConflictAlgorithm.ignore,
            );
          }
        }

        if (oldVersion < 3) {
          // Columnas nuevas en inventario (Fase 2): contratistaId y
          // tipo. Los artículos existentes se asumen de CARSO (único
          // contratista hasta ahora) y de tipo consumible (lo único
          // que existía antes de Fase 2).
          await db.execute('ALTER TABLE inventario ADD COLUMN contratistaId TEXT');
          await db.execute('ALTER TABLE inventario ADD COLUMN tipo TEXT');
          await db.execute(
              "UPDATE inventario SET contratistaId = 'carso' WHERE contratistaId IS NULL");
          await db.execute(
              "UPDATE inventario SET tipo = 'consumible' WHERE tipo IS NULL");

          await db.execute('''
            CREATE TABLE IF NOT EXISTS equipos_seriados (
              id TEXT PRIMARY KEY,
              contratistaId TEXT,
              tipoEquipo TEXT,
              serie TEXT,
              estado TEXT,
              otIdInstalado TEXT,
              fechaIngreso TEXT
            )
          ''');

          await db.execute('''
            CREATE TABLE IF NOT EXISTS herramientas (
              id TEXT PRIMARY KEY,
              contratistaId TEXT,
              nombre TEXT,
              estado TEXT,
              ultimoChequeo TEXT
            )
          ''');
        }

        if (oldVersion < 4) {
          // Columna nueva en contratistas (Fase 3): tarifarioVigenteDesde.
          // Los contratistas existentes (CARSO, COLSAGO) quedan con la
          // fecha por defecto del 1/1/2026 si no tenían una — coincide
          // con lo que ya asumía el modelo en memoria antes de esta
          // migración.
          await db.execute(
              'ALTER TABLE contratistas ADD COLUMN tarifarioVigenteDesde TEXT');
          await db.execute(
              "UPDATE contratistas SET tarifarioVigenteDesde = '2026-01-01T00:00:00.000' WHERE tarifarioVigenteDesde IS NULL");

          // Columna nueva en liquidaciones: contratistaId, para poder
          // separar "Por Facturar" por contratista sin tener que hacer
          // join con ordenes_trabajo en cada consulta. Las liquidaciones
          // existentes (todas de antes de Fase 3) se completan
          // buscando el contratista de su OT asociada; si la OT ya no
          // existe, se asume CARSO como respaldo.
          await db.execute('ALTER TABLE liquidaciones ADD COLUMN contratistaId TEXT');
          final liquidacionesSinContratista = await db.query(
            'liquidaciones',
            where: 'contratistaId IS NULL',
          );
          for (final liq in liquidacionesSinContratista) {
            final otRelacionada = await db.query(
              'ordenes_trabajo',
              where: 'id = ?',
              whereArgs: [liq['otId']],
              limit: 1,
            );
            final contratistaDeLaOt = otRelacionada.isNotEmpty
                ? (otRelacionada.first['contratistaId'] as String? ?? 'carso')
                : 'carso';
            await db.update(
              'liquidaciones',
              {'contratistaId': contratistaDeLaOt},
              where: 'id = ?',
              whereArgs: [liq['id']],
            );
          }

          await db.execute('''
            CREATE TABLE IF NOT EXISTS feriados (
              id TEXT PRIMARY KEY,
              fecha TEXT,
              nombre TEXT
            )
          ''');

          // Precarga los feriados oficiales de Costa Rica si la tabla
          // está vacía (instalación que viene de una versión anterior,
          // donde esta tabla no existía y por lo tanto no tiene datos).
          final yaTieneFeriados = await db.query('feriados', limit: 1);
          if (yaTieneFeriados.isEmpty) {
            for (final f in feriadosCostaRicaIniciales) {
              await db.insert('feriados', f.toMap(),
                  conflictAlgorithm: ConflictAlgorithm.ignore);
            }
          }
        }
      },
    );
  }

  // ---------------- INVENTARIO ----------------

  Future<void> upsertArticulo(ArticuloInventario articulo) async {
    final db = await database;
    await db.insert(
      'inventario',
      articulo.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<ArticuloInventario>> obtenerInventario() async {
    final db = await database;
    final rows = await db.query('inventario', orderBy: 'nombre ASC');
    return rows.map((r) => ArticuloInventario.fromMap(r)).toList();
  }

  Future<List<ArticuloInventario>> obtenerAlertasCriticas() async {
    final inventario = await obtenerInventario();
    return inventario.where((a) => a.enAlertaCritica).toList();
  }

  Future<void> descontarInventario(
    String articuloId,
    double cantidad,
    String otId,
  ) async {
    final db = await database;
    final rows =
        await db.query('inventario', where: 'id = ?', whereArgs: [articuloId]);
    if (rows.isEmpty) return;

    final articulo = ArticuloInventario.fromMap(rows.first);
    articulo.cantidadDisponible -= cantidad;
    await upsertArticulo(articulo);

    await db.insert('movimientos_inventario', {
      'id': '${DateTime.now().millisecondsSinceEpoch}_$articuloId',
      'articuloId': articuloId,
      'fecha': DateTime.now().toIso8601String(),
      'cantidad': cantidad,
      'tipo': 'consumo',
      'otId': otId,
    });
  }

  Future<void> eliminarArticulo(String id) async {
    final db = await database;
    await db.delete('inventario', where: 'id = ?', whereArgs: [id]);
  }

  // ---------------- ORDENES DE TRABAJO ----------------

  Future<void> upsertOT(OrdenTrabajo ot) async {
    final db = await database;
    final map = ot.toMap();
    map['materialesConsumidosJson'] =
        jsonEncode(ot.materialesConsumidos.map((m) => m.toMap()).toList());
    map['adicionalesFacturadosJson'] =
        jsonEncode(ot.adicionalesFacturados.map((a) => a.toMap()).toList());
    // Log de equipos (instalado/desinstalado por serie), Fase 1.
    map['logEquiposJson'] =
        jsonEncode(ot.logEquipos.map((e) => e.toMap()).toList());

    await db.insert(
      'ordenes_trabajo',
      map,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<OrdenTrabajo>> obtenerOrdenes({EstadoOT? filtroEstado}) async {
    final db = await database;
    final rows = await db.query(
      'ordenes_trabajo',
      orderBy: 'fechaCreacion DESC',
    );

    final ordenes = rows.map((r) {
      final ot = OrdenTrabajo.fromMap(r);
      final materialesJson = r['materialesConsumidosJson'] as String?;
      final adicionalesJson = r['adicionalesFacturadosJson'] as String?;
      final logEquiposJson = r['logEquiposJson'] as String?;

      if (materialesJson != null && materialesJson.isNotEmpty) {
        final lista = jsonDecode(materialesJson) as List;
        ot.materialesConsumidos =
            lista.map((m) => MaterialConsumido.fromMap(m)).toList();
      }
      if (adicionalesJson != null && adicionalesJson.isNotEmpty) {
        final lista = jsonDecode(adicionalesJson) as List;
        ot.adicionalesFacturados =
            lista.map((a) => AdicionalFacturado.fromMap(a)).toList();
      }
      // OTs guardadas antes de Fase 1 no tendrán esta columna con datos
      // (será null o ''); en ese caso logEquipos queda vacío, que es el
      // valor por defecto que ya pone el constructor de OrdenTrabajo.
      if (logEquiposJson != null && logEquiposJson.isNotEmpty) {
        final lista = jsonDecode(logEquiposJson) as List;
        ot.logEquipos = lista.map((e) => EventoEquipo.fromMap(e)).toList();
      }
      return ot;
    }).toList();

    if (filtroEstado != null) {
      return ordenes.where((o) => o.estadoFlujo == filtroEstado).toList();
    }
    return ordenes;
  }

  Future<void> eliminarOT(String id) async {
    final db = await database;
    await db.delete('ordenes_trabajo', where: 'id = ?', whereArgs: [id]);
  }

  // ---------------- LIQUIDACIONES / POR FACTURAR ----------------

  Future<void> registrarLiquidacion({
    required String otId,
    required String contratistaId,
    required double monto,
    required String descripcion,
  }) async {
    final db = await database;
    await db.insert('liquidaciones', {
      'id': '${DateTime.now().millisecondsSinceEpoch}_$otId',
      'otId': otId,
      'contratistaId': contratistaId,
      'fecha': DateTime.now().toIso8601String(),
      'monto': monto,
      'descripcion': descripcion,
      'facturada': 0,
    });
  }

  Future<List<Map<String, dynamic>>> obtenerPorFacturar({
    DateTime? desde,
    DateTime? hasta,
    String? contratistaId,
  }) async {
    final db = await database;
    String where = 'facturada = 0';
    List<dynamic> args = [];

    if (desde != null) {
      where += ' AND fecha >= ?';
      args.add(desde.toIso8601String());
    }
    if (hasta != null) {
      where += ' AND fecha <= ?';
      args.add(hasta.toIso8601String());
    }
    if (contratistaId != null) {
      where += ' AND contratistaId = ?';
      args.add(contratistaId);
    }

    return db.query('liquidaciones', where: where, whereArgs: args, orderBy: 'fecha DESC');
  }

  Future<double> totalPorFacturar({DateTime? desde, DateTime? hasta, String? contratistaId}) async {
    final filas = await obtenerPorFacturar(desde: desde, hasta: hasta, contratistaId: contratistaId);
    return filas.fold<double>(0, (acc, f) => acc + (f['monto'] as num).toDouble());
  }

  Future<void> marcarComoFacturadas(List<String> ids) async {
    final db = await database;
    final batch = db.batch();
    for (final id in ids) {
      batch.update('liquidaciones', {'facturada': 1},
          where: 'id = ?', whereArgs: [id]);
    }
    await batch.commit(noResult: true);
  }

  // ---------------- CONTRATISTAS ----------------

  Future<List<Contratista>> obtenerContratistas({bool soloActivos = false}) async {
    final db = await database;
    final rows = await db.query(
      'contratistas',
      where: soloActivos ? 'activo = 1' : null,
      orderBy: 'nombre ASC',
    );
    return rows.map((r) => Contratista.fromMap(r)).toList();
  }

  Future<void> upsertContratista(Contratista contratista) async {
    final db = await database;
    await db.insert(
      'contratistas',
      contratista.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ---------------- EQUIPOS SERIADOS (Fase 2) ----------------

  Future<List<EquipoSeriado>> obtenerEquiposSeriados({String? contratistaId}) async {
    final db = await database;
    final rows = await db.query(
      'equipos_seriados',
      where: contratistaId != null ? 'contratistaId = ?' : null,
      whereArgs: contratistaId != null ? [contratistaId] : null,
      orderBy: 'fechaIngreso DESC',
    );
    return rows.map((r) => EquipoSeriado.fromMap(r)).toList();
  }

  Future<void> upsertEquipoSeriado(EquipoSeriado equipo) async {
    final db = await database;
    await db.insert(
      'equipos_seriados',
      equipo.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> eliminarEquipoSeriado(String id) async {
    final db = await database;
    await db.delete('equipos_seriados', where: 'id = ?', whereArgs: [id]);
  }

  // ---------------- HERRAMIENTAS (Fase 2) ----------------

  Future<List<Herramienta>> obtenerHerramientas({String? contratistaId}) async {
    final db = await database;
    final rows = await db.query(
      'herramientas',
      where: contratistaId != null ? 'contratistaId = ?' : null,
      whereArgs: contratistaId != null ? [contratistaId] : null,
      orderBy: 'nombre ASC',
    );
    return rows.map((r) => Herramienta.fromMap(r)).toList();
  }

  Future<void> upsertHerramienta(Herramienta herramienta) async {
    final db = await database;
    await db.insert(
      'herramientas',
      herramienta.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ---------------- FERIADOS (Fase 3) ----------------

  Future<List<Feriado>> obtenerFeriados() async {
    final db = await database;
    final rows = await db.query('feriados', orderBy: 'fecha ASC');
    return rows.map((r) => Feriado.fromMap(r)).toList();
  }

  Future<void> upsertFeriado(Feriado feriado) async {
    final db = await database;
    await db.insert(
      'feriados',
      feriado.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> eliminarFeriado(String id) async {
    final db = await database;
    await db.delete('feriados', where: 'id = ?', whereArgs: [id]);
  }
}
