// lib/services/facturacion_service.dart
//
// Lógica de cálculo de mano de obra por OT: tarifa base del combo
// (One/Two/Triple Play) + adicionales medidos (metros extra, equipos
// adicionales, etc.)
//
// FASE 3 (26/06/2026): cada contratista tiene su propio tarifario
// independiente (ver tarifa.dart). Por eso todos los métodos de este
// servicio ahora reciben o derivan el contratistaId, y buscan dentro
// de tarifarioDe(contratistaId) en vez de una lista única compartida.

import '../models/orden_trabajo.dart';
import '../models/tarifa.dart';

class ResultadoFacturacion {
  final double totalBase;
  final double totalAdicionales;
  final double totalGeneral;
  final List<String> detalle;

  ResultadoFacturacion({
    required this.totalBase,
    required this.totalAdicionales,
    required this.totalGeneral,
    required this.detalle,
  });
}

class FacturacionService {
  /// Sugiere la tarifa base de instalación de abonado según el subtipo
  /// de la OT (texto libre que viene del sistema de despacho) y el
  /// contratista de esa OT (cada contratista tiene su propio tarifario).
  ///
  /// Esto es una sugerencia inicial; el técnico siempre puede cambiarla
  /// manualmente en la pantalla de liquidación, porque el texto del
  /// subtipo no siempre es 100% consistente.
  static Tarifa? sugerirTarifaBase(String subtipo, String contratistaId) {
    final tarifario = tarifarioDe(contratistaId);
    if (tarifario.isEmpty) return null; // contratista sin tarifario cargado

    final s = subtipo.toLowerCase();

    final tieneInternet = s.contains('internet');
    final tieneTv = s.contains('tv') || s.contains('televisión') || s.contains('television');
    final tieneVoz = s.contains('voz');

    final cuentaServicios =
        [tieneInternet, tieneTv, tieneVoz].where((b) => b).length;

    Tarifa? buscar(String id) {
      final coincidencias = tarifario.where((t) => t.id == id);
      return coincidencias.isEmpty ? null : coincidencias.first;
    }

    if (cuentaServicios >= 3) {
      return buscar('inst_triple');
    }
    if (cuentaServicios == 2) {
      if (tieneInternet && tieneTv) return buscar('inst_two_internet_tv');
      if (tieneInternet && tieneVoz) return buscar('inst_two_voz_internet');
      if (tieneTv && tieneVoz) return buscar('inst_two_tv_voz');
    }
    if (cuentaServicios == 1) {
      if (tieneInternet) return buscar('inst_one_internet');
      if (tieneTv) return buscar('inst_one_tv');
      if (tieneVoz) return buscar('inst_one_voz');
    }
    return null; // no se pudo sugerir, el técnico elige manualmente
  }

  /// Calcula el total a facturar de una OT, buscando las tarifas en el
  /// tarifario de SU contratista (ot.contratistaId) — no en una lista
  /// global, porque cada contratista puede tener precios distintos.
  static ResultadoFacturacion calcular(OrdenTrabajo ot) {
    final tarifario = tarifarioDe(ot.contratistaId);
    double totalBase = 0;
    double totalAdicionales = 0;
    final detalle = <String>[];

    if (ot.tarifaBaseId != null) {
      final coincidencias =
          tarifario.where((t) => t.id == ot.tarifaBaseId).toList();
      if (coincidencias.isEmpty) {
        throw Exception(
            'Tarifa base no encontrada en el tarifario de ${ot.contratistaId}');
      }
      final tarifa = coincidencias.first;
      totalBase = tarifa.valor;
      detalle.add('${tarifa.descripcion}: ₡${tarifa.valor.toStringAsFixed(2)}');
    }

    for (final adicional in ot.adicionalesFacturados) {
      totalAdicionales += adicional.subtotal;
      final coincidencias =
          tarifario.where((t) => t.id == adicional.tarifaId).toList();
      final tarifa = coincidencias.isNotEmpty
          ? coincidencias.first
          : Tarifa(
              id: adicional.tarifaId,
              contratistaId: ot.contratistaId,
              descripcion: 'Adicional desconocido',
              unidad: 'UN',
              valor: 0,
              tipo: TipoTarifa.otro,
            );
      detalle.add(
        '${tarifa.descripcion} x${adicional.cantidad}: ₡${adicional.subtotal.toStringAsFixed(2)}',
      );
    }

    return ResultadoFacturacion(
      totalBase: totalBase,
      totalAdicionales: totalAdicionales,
      totalGeneral: totalBase + totalAdicionales,
      detalle: detalle,
    );
  }

  /// Calcula el subtotal de un adicional medido por metro (cable UTP,
  /// drop FO, canaleta) dada la cantidad de metros INSTALADOS EN TOTAL
  /// (no solo el excedente; el método se encarga de restar el umbral),
  /// buscando la tarifa en el tarifario del contratista indicado.
  ///
  /// CORRECCIÓN (25/06/2026): antes este método cobraba el total de
  /// metros sin restar el umbral incluido (ej. 8m de UTP se cobraban
  /// como 8m completos en vez de solo 3m de excedente sobre los 5m
  /// incluidos). Esto sobrecobraba en cada instalación con metraje
  /// dentro o cerca del umbral. Ahora usa calcularSubtotalConUmbral,
  /// que resta el umbral antes de multiplicar por el valor unitario.
  /// Para tarifas sin umbral (ej. metro_canaleta), el umbral es 0 y el
  /// cálculo se comporta igual que antes (metros completos × valor).
  static double calcularSubtotalPorMetro(
      String contratistaId, String tarifaId, double metrosInstalados) {
    final tarifario = tarifarioDe(contratistaId);
    final tarifa = tarifario.firstWhere((t) => t.id == tarifaId);
    return tarifa.calcularSubtotalConUmbral(metrosInstalados);
  }
}
