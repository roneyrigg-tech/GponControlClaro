// lib/screens/configuracion_screen.dart
//
// FASE 3 (26/06/2026): pantalla de configuración con dos secciones:
//   - Contratistas: ver los existentes (CARSO, COLSAGO) y agregar uno
//     nuevo (nombre, razón social, cédula jurídica). Cada contratista
//     nuevo es su propio "árbol" — su tarifario queda vacío hasta que
//     se cargue manualmente (ver tarifa.dart, tarifarioDe()).
//   - Feriados: lista fija de feriados de Costa Rica (editable),
//     usada por QuincenaService para el cierre de quincena.

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/contratista.dart';
import '../models/feriado.dart';
import '../models/tarifa.dart';
import '../services/configuracion_provider.dart';

class ConfiguracionScreen extends StatelessWidget {
  const ConfiguracionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Más')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          _SeccionContratistas(),
          SizedBox(height: 28),
          _SeccionFeriados(),
        ],
      ),
    );
  }
}

class _SeccionContratistas extends StatelessWidget {
  const _SeccionContratistas();

  @override
  Widget build(BuildContext context) {
    return Consumer<ConfiguracionProvider>(
      builder: (context, provider, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Contratistas', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                TextButton.icon(
                  onPressed: () => _abrirFormularioContratista(context),
                  icon: const Icon(Icons.add),
                  label: const Text('Agregar'),
                ),
              ],
            ),
            const SizedBox(height: 4),
            const Text(
              'Cada contratista tiene su propio tarifario, inventario y equipos por separado.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 10),
            if (provider.contratistas.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Sin contratistas registrados', style: TextStyle(color: Colors.grey)),
              )
            else
              ...provider.contratistas.map((c) => _TarjetaContratista(contratista: c)),
          ],
        );
      },
    );
  }

  void _abrirFormularioContratista(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _FormularioContratista(),
    );
  }
}

class _TarjetaContratista extends StatelessWidget {
  final Contratista contratista;
  const _TarjetaContratista({required this.contratista});

  @override
  Widget build(BuildContext context) {
    final formatoFecha = DateFormat('dd/MM/yyyy');
    final cantidadTarifas = tarifarioDe(contratista.id).length;

    return Card(
      child: ListTile(
        title: Text(contratista.nombre, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(contratista.razonSocial, style: const TextStyle(fontSize: 11.5)),
            if (contratista.cedulaJuridica != null && contratista.cedulaJuridica!.isNotEmpty)
              Text('Cédula: ${contratista.cedulaJuridica}', style: const TextStyle(fontSize: 11.5)),
            const SizedBox(height: 4),
            Text(
              cantidadTarifas == 0
                  ? 'Sin tarifario cargado'
                  : '$cantidadTarifas tarifa(s) cargadas · vigente desde ${formatoFecha.format(contratista.tarifarioVigenteDesde)}',
              style: TextStyle(
                fontSize: 11,
                color: cantidadTarifas == 0 ? const Color(0xFFE8531C) : Colors.grey,
                fontWeight: cantidadTarifas == 0 ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FormularioContratista extends StatefulWidget {
  const _FormularioContratista();

  @override
  State<_FormularioContratista> createState() => _FormularioContratistaState();
}

class _FormularioContratistaState extends State<_FormularioContratista> {
  final _nombreCtrl = TextEditingController();
  final _razonSocialCtrl = TextEditingController();
  final _cedulaCtrl = TextEditingController();

  void _guardar() {
    final nombre = _nombreCtrl.text.trim();
    final razonSocial = _razonSocialCtrl.text.trim();
    if (nombre.isEmpty || razonSocial.isEmpty) return;

    context.read<ConfiguracionProvider>().agregarContratista(
          nombre: nombre,
          razonSocial: razonSocial,
          cedulaJuridica: _cedulaCtrl.text.trim().isEmpty ? null : _cedulaCtrl.text.trim(),
        );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Nuevo contratista', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 4),
            const Text(
              'Arranca con su propio tarifario vacío — lo cargás después desde el código o, más adelante, desde esta misma pantalla.',
              style: TextStyle(fontSize: 11.5, color: Colors.grey),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _nombreCtrl,
              decoration: const InputDecoration(labelText: 'Nombre (ej. TecnoRed)'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _razonSocialCtrl,
              decoration: const InputDecoration(labelText: 'Razón social completa'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _cedulaCtrl,
              decoration: const InputDecoration(labelText: 'Cédula jurídica (opcional)'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _guardar,
              style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
  }
}

class _SeccionFeriados extends StatelessWidget {
  const _SeccionFeriados();

  @override
  Widget build(BuildContext context) {
    final formatoFecha = DateFormat('dd/MM/yyyy');

    return Consumer<ConfiguracionProvider>(
      builder: (context, provider, _) {
        final feriadosOrdenados = [...provider.feriados]
          ..sort((a, b) => a.fecha.compareTo(b.fecha));

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Feriados (Costa Rica)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                TextButton.icon(
                  onPressed: () => _abrirFormularioFeriado(context),
                  icon: const Icon(Icons.add),
                  label: const Text('Agregar'),
                ),
              ],
            ),
            const SizedBox(height: 4),
            const Text(
              'Se usan para calcular el cierre de quincena (15/30 se corre al día hábil anterior si cae aquí).',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 10),
            if (feriadosOrdenados.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Sin feriados registrados', style: TextStyle(color: Colors.grey)),
              )
            else
              ...feriadosOrdenados.map((f) => Card(
                    child: ListTile(
                      dense: true,
                      title: Text(f.nombre, style: const TextStyle(fontSize: 13.5)),
                      subtitle: Text(formatoFecha.format(f.fecha), style: const TextStyle(fontSize: 11.5)),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, size: 20, color: Colors.grey),
                        onPressed: () => provider.eliminarFeriado(f.id),
                      ),
                    ),
                  )),
          ],
        );
      },
    );
  }

  void _abrirFormularioFeriado(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _FormularioFeriado(),
    );
  }
}

class _FormularioFeriado extends StatefulWidget {
  const _FormularioFeriado();

  @override
  State<_FormularioFeriado> createState() => _FormularioFeriadoState();
}

class _FormularioFeriadoState extends State<_FormularioFeriado> {
  final _nombreCtrl = TextEditingController();
  DateTime _fecha = DateTime.now();

  Future<void> _elegirFecha() async {
    final seleccionada = await showDatePicker(
      context: context,
      initialDate: _fecha,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (seleccionada != null) setState(() => _fecha = seleccionada);
  }

  void _guardar() {
    final nombre = _nombreCtrl.text.trim();
    if (nombre.isEmpty) return;
    context.read<ConfiguracionProvider>().agregarFeriado(_fecha, nombre);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final formatoFecha = DateFormat('dd/MM/yyyy');

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Nuevo feriado', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Fecha'),
              subtitle: Text(formatoFecha.format(_fecha)),
              trailing: const Icon(Icons.calendar_today_outlined),
              onTap: _elegirFecha,
            ),
            TextField(
              controller: _nombreCtrl,
              decoration: const InputDecoration(labelText: 'Nombre del feriado'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _guardar,
              style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
  }
}
