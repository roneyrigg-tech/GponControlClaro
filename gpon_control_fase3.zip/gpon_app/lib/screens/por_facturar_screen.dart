// lib/screens/por_facturar_screen.dart
//
// FASE 3 (26/06/2026): se agrega el rango "Quincena" usando
// QuincenaService (cierre día 15/30 ajustado a día hábil según
// feriados de Costa Rica), y la lista se separa por contratista,
// porque cada contratista se factura por separado con su propia razón
// social y la del técnico que factura.

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/contratista.dart';
import '../models/feriado.dart';
import '../services/database_service.dart';
import '../services/quincena_service.dart';

class PorFacturarScreen extends StatefulWidget {
  const PorFacturarScreen({super.key});

  @override
  State<PorFacturarScreen> createState() => _PorFacturarScreenState();
}

enum _Rango { quincena, semana, mes, todo }

class _PorFacturarScreenState extends State<PorFacturarScreen> {
  _Rango _rango = _Rango.quincena;
  String? _contratistaId; // null = todos los contratistas juntos
  List<Feriado> _feriados = [];
  PeriodoQuincena? _periodoActual;
  Map<String, List<Map<String, dynamic>>> _filasPorContratista = {};
  double _total = 0;
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<(DateTime?, DateTime?)> _rangoDeFechas() async {
    final ahora = DateTime.now();
    switch (_rango) {
      case _Rango.quincena:
        _feriados = await DatabaseService.instance.obtenerFeriados();
        _periodoActual = QuincenaService.periodoQueContiene(ahora, _feriados);
        return (_periodoActual!.inicio, _periodoActual!.fin);
      case _Rango.semana:
        _periodoActual = null;
        return (ahora.subtract(Duration(days: ahora.weekday - 1)), null);
      case _Rango.mes:
        _periodoActual = null;
        return (DateTime(ahora.year, ahora.month, 1), null);
      case _Rango.todo:
        _periodoActual = null;
        return (null, null);
    }
  }

  Future<void> _cargar() async {
    setState(() => _cargando = true);
    final (desde, hasta) = await _rangoDeFechas();

    final todasLasFilas = await DatabaseService.instance.obtenerPorFacturar(
      desde: desde,
      hasta: hasta,
      contratistaId: _contratistaId,
    );

    // Agrupar por contratista para mostrar secciones separadas (cada
    // contratista se factura aparte, con su propia razón social).
    final agrupado = <String, List<Map<String, dynamic>>>{};
    for (final fila in todasLasFilas) {
      final cId = fila['contratistaId'] as String? ?? 'carso';
      agrupado.putIfAbsent(cId, () => []).add(fila);
    }

    final total = todasLasFilas.fold<double>(0, (acc, f) => acc + (f['monto'] as num).toDouble());

    setState(() {
      _filasPorContratista = agrupado;
      _total = total;
      _cargando = false;
    });
  }

  Future<void> _marcarFacturadas(List<Map<String, dynamic>> filas, String nombreContratista) async {
    if (filas.isEmpty) return;
    final totalGrupo = filas.fold<double>(0, (acc, f) => acc + (f['monto'] as num).toDouble());

    final confirmar = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Marcar facturadas — $nombreContratista'),
        content: Text(
          'Se marcarán ${filas.length} liquidaciones de $nombreContratista por un total de '
          '₡${totalGrupo.toStringAsFixed(2)} como ya cobradas. ¿Confirmás?',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Confirmar')),
        ],
      ),
    );

    if (confirmar != true) return;

    final ids = filas.map((f) => f['id'] as String).toList();
    await DatabaseService.instance.marcarComoFacturadas(ids);
    await _cargar();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Liquidaciones de $nombreContratista marcadas como facturadas ✓')),
      );
    }
  }

  String _nombreContratista(String id) {
    final coincidencias = contratistasIniciales.where((c) => c.id == id);
    return coincidencias.isNotEmpty ? coincidencias.first.nombre : id.toUpperCase();
  }

  Contratista? _datosContratista(String id) {
    final coincidencias = contratistasIniciales.where((c) => c.id == id);
    return coincidencias.isNotEmpty ? coincidencias.first : null;
  }

  @override
  Widget build(BuildContext context) {
    final formatoFecha = DateFormat('dd/MM/yyyy');

    return Scaffold(
      appBar: AppBar(title: const Text('Por Facturar')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: SegmentedButton<_Rango>(
              segments: const [
                ButtonSegment(value: _Rango.quincena, label: Text('Quincena')),
                ButtonSegment(value: _Rango.semana, label: Text('Semana')),
                ButtonSegment(value: _Rango.mes, label: Text('Mes')),
                ButtonSegment(value: _Rango.todo, label: Text('Todo')),
              ],
              selected: {_rango},
              onSelectionChanged: (set) {
                setState(() => _rango = set.first);
                _cargar();
              },
            ),
          ),

          if (_rango == _Rango.quincena && _periodoActual != null)
            Container(
              margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFEFF6FF),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(Icons.event_outlined, size: 18, color: Color(0xFF0B5FFF)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Período: ${formatoFecha.format(_periodoActual!.inicio)} — ${formatoFecha.format(_periodoActual!.fin)}'
                      '${_periodoActual!.seAjustoPorDiaInhabil ? " (cierre ajustado por día inhábil, nominal ${formatoFecha.format(_periodoActual!.fechaNominal)})" : ""}',
                      style: const TextStyle(fontSize: 12, color: Color(0xFF0B5FFF)),
                    ),
                  ),
                ],
              ),
            ),

          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            padding: const EdgeInsets.all(18),
            width: double.infinity,
            decoration: BoxDecoration(
              color: const Color(0xFF14213D),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'TOTAL ACUMULADO POR COBRAR',
                  style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                ),
                const SizedBox(height: 6),
                Text(
                  '₡${_total.toStringAsFixed(2)}',
                  style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  '${_filasPorContratista.values.fold<int>(0, (acc, l) => acc + l.length)} orden(es) liquidada(s) sin cobrar',
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _cargando
                ? const Center(child: CircularProgressIndicator())
                : _filasPorContratista.isEmpty
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(32),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.receipt_long_outlined, size: 56, color: Colors.grey),
                              const SizedBox(height: 12),
                              const Text(
                                'No hay liquidaciones pendientes en este rango',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                      )
                    : ListView(
                        padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
                        children: _filasPorContratista.entries.map((entry) {
                          final contratistaId = entry.key;
                          final filas = entry.value;
                          final nombre = _nombreContratista(contratistaId);
                          final contratista = _datosContratista(contratistaId);
                          final totalGrupo = filas.fold<double>(0, (acc, f) => acc + (f['monto'] as num).toDouble());

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(nombre, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                          if (contratista != null)
                                            Text(
                                              contratista.razonSocial,
                                              style: const TextStyle(fontSize: 11, color: Colors.grey),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                        ],
                                      ),
                                    ),
                                    Text(
                                      '₡${totalGrupo.toStringAsFixed(2)}',
                                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 6),
                                ...filas.map((f) {
                                  final fecha = DateTime.parse(f['fecha'] as String);
                                  return Card(
                                    child: ListTile(
                                      dense: true,
                                      title: Text(f['descripcion'] as String, style: const TextStyle(fontSize: 13)),
                                      subtitle: Text(formatoFecha.format(fecha), style: const TextStyle(fontSize: 11)),
                                      trailing: Text(
                                        '₡${(f['monto'] as num).toStringAsFixed(2)}',
                                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5),
                                      ),
                                    ),
                                  );
                                }),
                                const SizedBox(height: 6),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: OutlinedButton.icon(
                                    onPressed: () => _marcarFacturadas(filas, nombre),
                                    icon: const Icon(Icons.check, size: 16),
                                    label: const Text('Marcar facturadas'),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
          ),
        ],
      ),
    );
  }
}
