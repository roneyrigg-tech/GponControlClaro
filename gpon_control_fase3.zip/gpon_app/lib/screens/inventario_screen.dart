// lib/screens/inventario_screen.dart
//
// FASE 2 (25/06/2026): la pantalla de inventario se reorganiza en 3
// pestañas porque ahora maneja tres flujos distintos:
//   - Materiales: consumibles por cantidad (como ya existía).
//   - Equipos: equipos con número de serie individual (ONT/MESH/STB),
//     con su estado de trazabilidad.
//   - Herramientas: entregadas una sola vez, con chequeo mensual.
//
// El botón de cámara (captura + OCR) vive en la pestaña de Materiales
// y Equipos, porque ambos se alimentan de la misma hoja de bodega.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/articulo_inventario.dart';
import '../models/contratista.dart';
import '../services/inventario_provider.dart';
import 'captura_materiales_screen.dart';

class InventarioScreen extends StatefulWidget {
  const InventarioScreen({super.key});

  @override
  State<InventarioScreen> createState() => _InventarioScreenState();
}

class _InventarioScreenState extends State<InventarioScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _abrirFormularioMaterial(BuildContext context, {ArticuloInventario? articulo}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _FormularioArticulo(articuloExistente: articulo),
    );
  }

  Future<void> _abrirCaptura(BuildContext context) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const CapturaMaterialesScreen()),
    );
    // Al volver de la captura, refrescamos por si se guardaron ítems.
    if (mounted) context.read<InventarioProvider>().cargar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inventario'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Materiales'),
            Tab(text: 'Equipos'),
            Tab(text: 'Herramientas'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _TabMateriales(onEditar: (a) => _abrirFormularioMaterial(context, articulo: a)),
          const _TabEquipos(),
          const _TabHerramientas(),
        ],
      ),
      floatingActionButton: _tabController.index == 2
          ? null
          : FloatingActionButton.extended(
              onPressed: () => _abrirCaptura(context),
              icon: const Icon(Icons.camera_alt_outlined),
              label: const Text('Foto de bodega'),
            ),
    );
  }
}

class _TabMateriales extends StatelessWidget {
  final void Function(ArticuloInventario?) onEditar;
  const _TabMateriales({required this.onEditar});

  @override
  Widget build(BuildContext context) {
    return Consumer<InventarioProvider>(
      builder: (context, provider, _) {
        if (provider.cargando) {
          return const Center(child: CircularProgressIndicator());
        }

        final materiales = provider.articulos
            .where((a) => a.tipo == TipoArticulo.consumible)
            .toList();
        final enAlerta = provider.enAlerta;

        return RefreshIndicator(
          onRefresh: provider.cargar,
          child: CustomScrollView(
            slivers: [
              if (enAlerta.isNotEmpty)
                SliverToBoxAdapter(child: _BannerAlertas(articulos: enAlerta)),
              if (materiales.isEmpty)
                SliverFillRemaining(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.inventory_2_outlined, size: 64, color: Colors.grey),
                          const SizedBox(height: 16),
                          const Text(
                            'Sin materiales registrados',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Tocá el botón de cámara para leer tu hoja de bodega,\no agregalo a mano con el botón +.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.grey),
                          ),
                          const SizedBox(height: 20),
                          ElevatedButton.icon(
                            onPressed: () => onEditar(null),
                            icon: const Icon(Icons.add),
                            label: const Text('Agregar a mano'),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, i) {
                        final articulo = materiales[i];
                        return _TarjetaArticulo(
                          articulo: articulo,
                          onEditar: () => onEditar(articulo),
                        );
                      },
                      childCount: materiales.length,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _BannerAlertas extends StatelessWidget {
  final List<ArticuloInventario> articulos;
  const _BannerAlertas({required this.articulos});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF0EA),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE8531C).withOpacity(0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.warning_amber_rounded, color: Color(0xFFE8531C)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Material crítico bajo',
                  style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFE8531C)),
                ),
                const SizedBox(height: 4),
                Text(
                  articulos.map((a) => a.nombre).join(', '),
                  style: const TextStyle(fontSize: 12.5, color: Color(0xFFE8531C)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TarjetaArticulo extends StatelessWidget {
  final ArticuloInventario articulo;
  final VoidCallback onEditar;
  const _TarjetaArticulo({required this.articulo, required this.onEditar});

  @override
  Widget build(BuildContext context) {
    final critico = articulo.enAlertaCritica;
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        title: Text(articulo.nombre, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        subtitle: Text(
          articulo.codigo.isNotEmpty ? 'Código: ${articulo.codigo}' : ' ',
          style: const TextStyle(fontSize: 11.5),
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              '${articulo.cantidadDisponible.toStringAsFixed(1)} ${articulo.unidad}',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: critico ? const Color(0xFFE8531C) : Colors.black,
              ),
            ),
            Text(
              'mín. ${articulo.stockMinimo.toStringAsFixed(1)}',
              style: const TextStyle(fontSize: 10.5, color: Colors.grey),
            ),
          ],
        ),
        onTap: onEditar,
      ),
    );
  }
}

class _FormularioArticulo extends StatefulWidget {
  final ArticuloInventario? articuloExistente;
  const _FormularioArticulo({this.articuloExistente});

  @override
  State<_FormularioArticulo> createState() => _FormularioArticuloState();
}

class _FormularioArticuloState extends State<_FormularioArticulo> {
  late TextEditingController _codigoCtrl;
  late TextEditingController _nombreCtrl;
  late TextEditingController _cantidadCtrl;
  late TextEditingController _stockMinCtrl;
  String _unidad = 'U';
  late String _contratistaId;

  final List<String> _unidades = ['M', 'MTS', 'U', 'UD', 'UN'];

  @override
  void initState() {
    super.initState();
    final a = widget.articuloExistente;
    _codigoCtrl = TextEditingController(text: a?.codigo ?? '');
    _nombreCtrl = TextEditingController(text: a?.nombre ?? '');
    _cantidadCtrl = TextEditingController(text: a?.cantidadDisponible.toString() ?? '');
    _stockMinCtrl = TextEditingController(text: a?.stockMinimo.toString() ?? '');
    _unidad = a?.unidad ?? 'U';
    _contratistaId = a?.contratistaId ?? 'carso';
  }

  void _guardar() {
    final nombre = _nombreCtrl.text.trim();
    if (nombre.isEmpty) return;

    final articulo = ArticuloInventario(
      id: widget.articuloExistente?.id ??
          '${DateTime.now().millisecondsSinceEpoch}',
      contratistaId: _contratistaId,
      codigo: _codigoCtrl.text.trim(),
      nombre: nombre,
      tipo: TipoArticulo.consumible,
      cantidadDisponible: double.tryParse(_cantidadCtrl.text) ?? 0,
      stockMinimo: double.tryParse(_stockMinCtrl.text) ?? 0,
      unidad: _unidad,
    );

    context.read<InventarioProvider>().guardarArticulo(articulo);
    Navigator.pop(context);
  }

  void _eliminar() {
    if (widget.articuloExistente == null) return;
    context.read<InventarioProvider>().eliminarArticulo(widget.articuloExistente!.id);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.articuloExistente == null ? 'Nuevo material' : 'Editar material',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _contratistaId,
              decoration: const InputDecoration(labelText: 'Contratista'),
              items: contratistasIniciales
                  .map((c) => DropdownMenuItem(value: c.id, child: Text(c.nombre)))
                  .toList(),
              onChanged: (v) => setState(() => _contratistaId = v ?? _contratistaId),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _nombreCtrl,
              decoration: const InputDecoration(labelText: 'Nombre del artículo'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _codigoCtrl,
              decoration: const InputDecoration(labelText: 'Código (opcional)'),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _cantidadCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'Cantidad disponible'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _unidad,
                    decoration: const InputDecoration(labelText: 'Unidad'),
                    items: _unidades
                        .map((u) => DropdownMenuItem(value: u, child: Text(u)))
                        .toList(),
                    onChanged: (v) => setState(() => _unidad = v ?? _unidad),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _stockMinCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Stock mínimo (alerta cuando baje de aquí)',
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                if (widget.articuloExistente != null)
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _eliminar,
                      style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFE8531C)),
                      child: const Text('Eliminar'),
                    ),
                  ),
                if (widget.articuloExistente != null) const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _guardar,
                    child: const Text('Guardar'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TabEquipos extends StatelessWidget {
  const _TabEquipos();

  Color _colorEstado(EstadoEquipoSeriado estado) {
    switch (estado) {
      case EstadoEquipoSeriado.disponible:
        return const Color(0xFF1E8449);
      case EstadoEquipoSeriado.instalado:
        return const Color(0xFF0B5FFF);
      case EstadoEquipoSeriado.danado:
        return const Color(0xFF7A1F1F);
      case EstadoEquipoSeriado.devuelto:
        return Colors.grey;
    }
  }

  String _textoEstado(EstadoEquipoSeriado estado) {
    switch (estado) {
      case EstadoEquipoSeriado.disponible:
        return 'DISPONIBLE';
      case EstadoEquipoSeriado.instalado:
        return 'INSTALADO';
      case EstadoEquipoSeriado.danado:
        return 'DAÑADO';
      case EstadoEquipoSeriado.devuelto:
        return 'DEVUELTO';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<InventarioProvider>(
      builder: (context, provider, _) {
        if (provider.cargando) {
          return const Center(child: CircularProgressIndicator());
        }

        final equipos = provider.equipos;
        if (equipos.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.router_outlined, size: 64, color: Colors.grey),
                  const SizedBox(height: 16),
                  const Text(
                    'Sin equipos registrados',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Tocá el botón de cámara para leer las series de tu hoja de bodega.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            ),
          );
        }

        // Agrupados por estado para que lo disponible (lo que importa
        // para salir a trabajar) se vea primero.
        final disponibles = equipos.where((e) => e.estado == EstadoEquipoSeriado.disponible).toList();
        final otros = equipos.where((e) => e.estado != EstadoEquipoSeriado.disponible).toList();

        return RefreshIndicator(
          onRefresh: provider.cargar,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
            children: [
              if (disponibles.isNotEmpty) ...[
                Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 6),
                  child: Text(
                    'DISPONIBLES (${disponibles.length})',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.grey),
                  ),
                ),
                ...disponibles.map((e) => _filaEquipo(e)),
                const SizedBox(height: 16),
              ],
              if (otros.isNotEmpty) ...[
                Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 6),
                  child: Text(
                    'OTROS (${otros.length})',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.grey),
                  ),
                ),
                ...otros.map((e) => _filaEquipo(e)),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _filaEquipo(EquipoSeriado e) {
    return Card(
      child: ListTile(
        dense: true,
        title: Text('${e.tipoEquipo} ${e.serie}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
        subtitle: e.otIdInstalado != null
            ? Text('OT: ${e.otIdInstalado}', style: const TextStyle(fontSize: 11))
            : null,
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: _colorEstado(e.estado).withOpacity(0.12),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            _textoEstado(e.estado),
            style: TextStyle(color: _colorEstado(e.estado), fontWeight: FontWeight.bold, fontSize: 10.5),
          ),
        ),
      ),
    );
  }
}

class _TabHerramientas extends StatelessWidget {
  const _TabHerramientas();

  @override
  Widget build(BuildContext context) {
    return Consumer<InventarioProvider>(
      builder: (context, provider, _) {
        if (provider.cargando) {
          return const Center(child: CircularProgressIndicator());
        }

        final herramientas = provider.herramientas;

        return RefreshIndicator(
          onRefresh: provider.cargar,
          child: herramientas.isEmpty
              ? ListView(
                  padding: const EdgeInsets.all(32),
                  children: [
                    const SizedBox(height: 60),
                    const Icon(Icons.build_outlined, size: 64, color: Colors.grey),
                    const SizedBox(height: 16),
                    const Text(
                      'Sin herramientas registradas',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Las herramientas se entregan una sola vez. Agregalas aquí para llevar el chequeo mensual.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 20),
                    Center(
                      child: ElevatedButton.icon(
                        onPressed: () => _abrirFormularioHerramienta(context),
                        icon: const Icon(Icons.add),
                        label: const Text('Agregar herramienta'),
                      ),
                    ),
                  ],
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
                  itemCount: herramientas.length + 1,
                  itemBuilder: (context, i) {
                    if (i == herramientas.length) {
                      return Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: OutlinedButton.icon(
                          onPressed: () => _abrirFormularioHerramienta(context),
                          icon: const Icon(Icons.add),
                          label: const Text('Agregar herramienta'),
                        ),
                      );
                    }
                    final h = herramientas[i];
                    return _filaHerramienta(context, h);
                  },
                ),
        );
      },
    );
  }

  void _abrirFormularioHerramienta(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _FormularioHerramienta(),
    );
  }

  Widget _filaHerramienta(BuildContext context, Herramienta h) {
    final necesitaChequeo = h.ultimoChequeo == null ||
        DateTime.now().difference(h.ultimoChequeo!).inDays >= 30;

    return Card(
      child: ListTile(
        title: Text(h.nombre, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        subtitle: Text(
          h.ultimoChequeo == null
              ? 'Sin chequear todavía'
              : 'Último chequeo: ${h.ultimoChequeo!.day}/${h.ultimoChequeo!.month}/${h.ultimoChequeo!.year}',
          style: const TextStyle(fontSize: 11.5),
        ),
        trailing: necesitaChequeo
            ? OutlinedButton(
                onPressed: () {
                  h.ultimoChequeo = DateTime.now();
                  h.estado = 'OK';
                  context.read<InventarioProvider>().guardarHerramienta(h);
                },
                style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFE8531C)),
                child: const Text('Chequear', style: TextStyle(fontSize: 12)),
              )
            : const Icon(Icons.check_circle, color: Color(0xFF1E8449)),
      ),
    );
  }
}

class _FormularioHerramienta extends StatefulWidget {
  const _FormularioHerramienta();

  @override
  State<_FormularioHerramienta> createState() => _FormularioHerramientaState();
}

class _FormularioHerramientaState extends State<_FormularioHerramienta> {
  final TextEditingController _nombreCtrl = TextEditingController();
  String _contratistaId = 'carso';

  void _guardar() {
    final nombre = _nombreCtrl.text.trim();
    if (nombre.isEmpty) return;

    final herramienta = Herramienta(
      id: '${DateTime.now().millisecondsSinceEpoch}',
      contratistaId: _contratistaId,
      nombre: nombre,
    );
    context.read<InventarioProvider>().guardarHerramienta(herramienta);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Nueva herramienta', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _contratistaId,
              decoration: const InputDecoration(labelText: 'Contratista'),
              items: contratistasIniciales
                  .map((c) => DropdownMenuItem(value: c.id, child: Text(c.nombre)))
                  .toList(),
              onChanged: (v) => setState(() => _contratistaId = v ?? _contratistaId),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _nombreCtrl,
              decoration: const InputDecoration(labelText: 'Nombre de la herramienta'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _guardar,
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
  }
}
