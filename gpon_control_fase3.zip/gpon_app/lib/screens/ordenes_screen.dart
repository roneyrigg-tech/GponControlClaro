// lib/screens/ordenes_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/orden_trabajo.dart';
import '../models/contratista.dart';
import '../models/articulo_inventario.dart';
import '../services/ot_provider.dart';
import '../services/inventario_provider.dart';
import 'ot_detalle_screen.dart';

class OrdenesScreen extends StatelessWidget {
  const OrdenesScreen({super.key});

  /// Pregunta de qué contratista es la OT antes de leer el portapapeles.
  /// El texto de Oracle no lo identifica de forma confiable, así que el
  /// técnico lo elige cada vez (queda como CARSO si cancela el diálogo,
  /// que es el comportamiento por defecto del parser).
  Future<String?> _elegirContratista(BuildContext context) {
    return showDialog<String>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('¿De qué contratista es esta OT?'),
        children: contratistasIniciales
            .map((c) => SimpleDialogOption(
                  onPressed: () => Navigator.pop(context, c.id),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Text(c.nombre, style: const TextStyle(fontSize: 15)),
                  ),
                ))
            .toList(),
      ),
    );
  }

  Future<void> _leerDelPortapapeles(BuildContext context) async {
    final contratistaId = await _elegirContratista(context);
    if (contratistaId == null) return; // técnico canceló el diálogo

    final data = await Clipboard.getData('text/plain');
    final texto = data?.text;

    if (texto == null || texto.trim().isEmpty) {
      _mostrarMensaje(context, 'El portapapeles está vacío. Copiá primero el texto de la OT.');
      return;
    }

    final provider = context.read<OTProvider>();
    final agregada = await provider.agregarDesdeTexto(texto, contratistaId: contratistaId);

    if (agregada) {
      // FASE 2 (25/06/2026): cuando la OT trae Log de Equipos con
      // eventos "instalado", esas series pasan de "disponible" a
      // "instalado" en el inventario del técnico. Si la serie no
      // estaba registrada en inventario (pudo instalarse sin pasar
      // antes por el flujo de foto+OCR de bodega), se asume que de
      // todas formas salió de circulación: no se crea como disponible,
      // se registra directo como instalada para no inflar el stock.
      final otRecienAgregada = OTParser.parse(texto, contratistaId: contratistaId);
      if (otRecienAgregada != null && otRecienAgregada.logEquipos.isNotEmpty) {
        final inventario = context.read<InventarioProvider>();
        final instalados = otRecienAgregada.logEquipos
            .where((e) => e.tipo == TipoEventoEquipo.instalado);
        for (final evento in instalados) {
          final yaExiste = inventario.equipos.any((eq) => eq.id == evento.serie);
          if (yaExiste) {
            await inventario.marcarInstalado(evento.serie, otRecienAgregada.id);
          } else {
            await inventario.agregarEquipoSeriado(EquipoSeriado(
              id: evento.serie,
              contratistaId: contratistaId,
              tipoEquipo: evento.tipoEquipo,
              serie: evento.serie,
              estado: EstadoEquipoSeriado.instalado,
              otIdInstalado: otRecienAgregada.id,
            ));
          }
        }
      }

      _mostrarMensaje(context, 'OT agregada correctamente ✓');
    } else {
      final otIntentada = OTParser.parse(texto, contratistaId: contratistaId);
      if (otIntentada == null) {
        _mostrarMensaje(
          context,
          'No se pudo leer una OT en ese texto. Verificá que copiaste el bloque completo.',
        );
      } else {
        _mostrarMensaje(
          context,
          'Esa OT (${otIntentada.numeroOT}) ya estaba registrada.',
        );
      }
    }
  }

  void _mostrarMensaje(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 3)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Órdenes de Trabajo')),
      body: Consumer<OTProvider>(
        builder: (context, provider, _) {
          if (provider.cargando) {
            return const Center(child: CircularProgressIndicator());
          }
          if (provider.ordenes.isEmpty) {
            return _EstadoVacio(onLeer: () => _leerDelPortapapeles(context));
          }
          return RefreshIndicator(
            onRefresh: provider.cargar,
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: provider.ordenes.length,
              itemBuilder: (context, i) {
                final ot = provider.ordenes[i];
                return _TarjetaOT(ot: ot);
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _leerDelPortapapeles(context),
        icon: const Icon(Icons.content_paste),
        label: const Text('Leer OT'),
      ),
    );
  }
}

class _EstadoVacio extends StatelessWidget {
  final VoidCallback onLeer;
  const _EstadoVacio({required this.onLeer});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.assignment_outlined, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            const Text(
              'No hay órdenes de trabajo todavía',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            const Text(
              'Copiá el texto de una OT desde el sistema de despacho y tocá "Leer OT".',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: onLeer,
              icon: const Icon(Icons.content_paste),
              label: const Text('Leer del portapapeles'),
            ),
          ],
        ),
      ),
    );
  }
}

class _TarjetaOT extends StatelessWidget {
  final OrdenTrabajo ot;
  const _TarjetaOT({required this.ot});

  Color _colorEstado(EstadoOT estado) {
    switch (estado) {
      case EstadoOT.pendiente:
        return Colors.grey;
      case EstadoOT.enRuta:
        return const Color(0xFFE8531C);
      case EstadoOT.instalado:
        return const Color(0xFF0B5FFF);
      case EstadoOT.liquidado:
        return const Color(0xFF1E8449);
    }
  }

  String _textoEstado(EstadoOT estado) {
    switch (estado) {
      case EstadoOT.pendiente:
        return 'PENDIENTE';
      case EstadoOT.enRuta:
        return 'EN RUTA';
      case EstadoOT.instalado:
        return 'INSTALADO';
      case EstadoOT.liquidado:
        return 'LIQUIDADO';
    }
  }

  @override
  Widget build(BuildContext context) {
    final nombreContratista = contratistasIniciales
        .firstWhere(
          (c) => c.id == ot.contratistaId,
          orElse: () => Contratista(
            id: ot.contratistaId,
            nombre: ot.contratistaId.toUpperCase(),
            razonSocial: '',
          ),
        )
        .nombre;

    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(14),
        title: Text(
          ot.nombreCliente.isEmpty ? ot.numeroOT : ot.nombreCliente,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0B5FFF).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      nombreContratista,
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF0B5FFF),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(ot.subtipo, style: const TextStyle(fontSize: 12.5)),
              const SizedBox(height: 4),
              Text(
                ot.direccion,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11.5, color: Colors.grey),
              ),
            ],
          ),
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: _colorEstado(ot.estadoFlujo).withOpacity(0.12),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            _textoEstado(ot.estadoFlujo),
            style: TextStyle(
              color: _colorEstado(ot.estadoFlujo),
              fontWeight: FontWeight.bold,
              fontSize: 10.5,
            ),
          ),
        ),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => OTDetalleScreen(ot: ot)),
          );
        },
      ),
    );
  }
}
