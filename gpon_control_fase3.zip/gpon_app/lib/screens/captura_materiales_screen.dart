// lib/screens/captura_materiales_screen.dart
//
// FASE 2 (25/06/2026): pantalla de captura de la hoja de bodega.
// Flujo: elegir contratista -> tomar/elegir foto -> OCR (OCRService)
// -> pantalla de confirmación donde el técnico revisa/corrige cada
// fila antes de aplicarla al inventario. El OCR NUNCA escribe directo
// a la base de datos; esta pantalla es el único punto donde se
// confirma y se guarda.
//
// Soporta varias fotos en una sola sesión de captura (la hoja puede
// venir en varias páginas), acumulando las filas candidatas de todas
// las fotos tomadas antes de mostrar la confirmación final.

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../models/articulo_inventario.dart';
import '../models/contratista.dart';
import '../services/inventario_provider.dart';
import '../services/ocr_service.dart';

class CapturaMaterialesScreen extends StatefulWidget {
  const CapturaMaterialesScreen({super.key});

  @override
  State<CapturaMaterialesScreen> createState() => _CapturaMaterialesScreenState();
}

class _CapturaMaterialesScreenState extends State<CapturaMaterialesScreen> {
  String _contratistaId = 'carso';
  final List<FilaOCRCandidata> _filas = [];
  bool _procesando = false;
  int _fotosLeidas = 0;

  Future<void> _tomarFoto() async {
    final picker = ImagePicker();
    final XFile? imagen = await picker.pickImage(source: ImageSource.camera, imageQuality: 85);
    if (imagen == null) return;
    await _procesarImagen(imagen.path);
  }

  Future<void> _elegirDeGaleria() async {
    final picker = ImagePicker();
    final XFile? imagen = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (imagen == null) return;
    await _procesarImagen(imagen.path);
  }

  Future<void> _procesarImagen(String ruta) async {
    setState(() => _procesando = true);
    try {
      final nuevasFilas = await OCRService.reconocerHojaMateriales(ruta);
      setState(() {
        _filas.addAll(nuevasFilas);
        _fotosLeidas++;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No se pudo leer la imagen: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _procesando = false);
    }
  }

  void _continuarAConfirmacion() {
    if (_filas.isEmpty) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => _ConfirmacionFilasScreen(
          contratistaId: _contratistaId,
          filasIniciales: _filas,
        ),
      ),
    );
  }

  @override
  void dispose() {
    // Libera el motor de OCR al salir de esta pantalla; si el técnico
    // vuelve a entrar, ML Kit lo vuelve a inicializar automáticamente
    // en la próxima llamada.
    OCRService.cerrar();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Leer hoja de bodega')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Contratista de esta entrega', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _contratistaId,
              items: contratistasIniciales
                  .map((c) => DropdownMenuItem(value: c.id, child: Text(c.nombre)))
                  .toList(),
              onChanged: (v) => setState(() => _contratistaId = v ?? _contratistaId),
            ),
            const SizedBox(height: 20),
            const Text(
              'Tomá una foto por cada hoja/página del recibo. Podés repetir hasta cubrir todo el documento.',
              style: TextStyle(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _procesando ? null : _tomarFoto,
                    icon: const Icon(Icons.camera_alt_outlined),
                    label: const Text('Tomar foto'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _procesando ? null : _elegirDeGaleria,
                    icon: const Icon(Icons.photo_library_outlined),
                    label: const Text('Galería'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            if (_procesando)
              const Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(height: 12),
                      Text('Leyendo la hoja...', style: TextStyle(color: Colors.grey)),
                    ],
                  ),
                ),
              )
            else if (_filas.isEmpty)
              const Expanded(
                child: Center(
                  child: Text(
                    'Todavía no leíste ninguna hoja.',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              )
            else
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$_fotosLeidas foto(s) leídas — ${_filas.length} ítem(s) detectados',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 8),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _filas.length,
                        itemBuilder: (context, i) {
                          final f = _filas[i];
                          return Card(
                            child: ListTile(
                              dense: true,
                              title: Text(f.descripcion, style: const TextStyle(fontSize: 13)),
                              subtitle: Text(
                                f.esSeriado ? 'Serie: ${f.serie}' : 'Cantidad: ${f.cantidad ?? "?"}',
                                style: const TextStyle(fontSize: 11),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: _continuarAConfirmacion,
                      style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                      child: const Text('Revisar y confirmar'),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// Pantalla de confirmación: el técnico revisa cada fila detectada por
/// OCR, corrige lo que esté mal (descripción, cantidad, serie), puede
/// destildar filas mal leídas, y solo entonces se aplica al inventario.
class _ConfirmacionFilasScreen extends StatefulWidget {
  final String contratistaId;
  final List<FilaOCRCandidata> filasIniciales;
  const _ConfirmacionFilasScreen({required this.contratistaId, required this.filasIniciales});

  @override
  State<_ConfirmacionFilasScreen> createState() => _ConfirmacionFilasScreenState();
}

class _ConfirmacionFilasScreenState extends State<_ConfirmacionFilasScreen> {
  late List<FilaOCRCandidata> _filas;

  @override
  void initState() {
    super.initState();
    // Copia mutable: cada fila se puede editar desde esta pantalla sin
    // afectar la lista original de la pantalla de captura.
    _filas = widget.filasIniciales
        .map((f) => FilaOCRCandidata(
              descripcion: f.descripcion,
              cantidad: f.cantidad,
              serie: f.serie,
              tipoEquipo: f.tipoEquipo,
              seleccionada: f.seleccionada,
            ))
        .toList();
  }

  Future<void> _editarFila(int index) async {
    final fila = _filas[index];
    final descripcionCtrl = TextEditingController(text: fila.descripcion);
    final cantidadCtrl = TextEditingController(text: fila.cantidad?.toString() ?? '');
    final serieCtrl = TextEditingController(text: fila.serie ?? '');

    final resultado = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Corregir ítem'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: descripcionCtrl,
              decoration: const InputDecoration(labelText: 'Descripción'),
            ),
            if (!fila.esSeriado)
              TextField(
                controller: cantidadCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Cantidad'),
              ),
            if (fila.esSeriado)
              TextField(
                controller: serieCtrl,
                decoration: const InputDecoration(labelText: 'Número de serie'),
              ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Guardar')),
        ],
      ),
    );

    if (resultado == true) {
      setState(() {
        fila.descripcion = descripcionCtrl.text.trim();
        if (!fila.esSeriado) {
          fila.cantidad = double.tryParse(cantidadCtrl.text);
        } else {
          fila.serie = serieCtrl.text.trim();
        }
      });
    }
  }

  Future<void> _confirmarTodo() async {
    final seleccionadas = _filas.where((f) => f.seleccionada).toList();
    if (seleccionadas.isEmpty) return;

    final provider = context.read<InventarioProvider>();

    final consumibles = seleccionadas.where((f) => !f.esSeriado).toList();
    final seriados = seleccionadas.where((f) => f.esSeriado).toList();

    // Consumibles: si ya existe un artículo con el mismo nombre para
    // este contratista, se SUMA la cantidad leída a la existente (la
    // hoja de bodega es una entrega nueva, no un reemplazo del stock
    // que ya tenía el técnico). Si no existe, se crea.
    for (final f in consumibles) {
      final existente = provider.articulos.where((a) =>
          a.contratistaId == widget.contratistaId &&
          a.tipo == TipoArticulo.consumible &&
          a.nombre.toLowerCase() == f.descripcion.toLowerCase()).toList();

      if (existente.isNotEmpty) {
        final articulo = existente.first;
        articulo.cantidadDisponible += (f.cantidad ?? 0);
        await provider.guardarArticulo(articulo);
      } else {
        await provider.guardarArticulo(ArticuloInventario(
          id: '${DateTime.now().millisecondsSinceEpoch}_${f.descripcion.hashCode}',
          contratistaId: widget.contratistaId,
          codigo: '',
          nombre: f.descripcion,
          tipo: TipoArticulo.consumible,
          cantidadDisponible: f.cantidad ?? 0,
          stockMinimo: 0,
          unidad: 'UN',
        ));
      }
    }

    // Equipos seriados: cada uno es una fila individual nueva, en
    // estado disponible (recién llegado de bodega a la mochila del
    // técnico). Si la serie ya existía (poco probable, pero posible si
    // se repite la foto), se ignora para no duplicar.
    final equiposNuevos = seriados
        .where((f) => f.serie != null && f.serie!.isNotEmpty)
        .where((f) => !provider.equipos.any((e) => e.id == f.serie))
        .map((f) => EquipoSeriado(
              id: f.serie!,
              contratistaId: widget.contratistaId,
              tipoEquipo: f.tipoEquipo ?? 'EQUIPO',
              serie: f.serie!,
            ))
        .toList();

    if (equiposNuevos.isNotEmpty) {
      await provider.agregarEquiposSeriados(equiposNuevos);
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${seleccionadas.length} ítem(s) agregados al inventario ✓')),
      );
      Navigator.of(context).popUntil((route) => route.isFirst);
    }
  }

  @override
  Widget build(BuildContext context) {
    final nombreContratista = contratistasIniciales
        .firstWhere((c) => c.id == widget.contratistaId, orElse: () => contratistasIniciales.first)
        .nombre;

    return Scaffold(
      appBar: AppBar(title: Text('Confirmar — $nombreContratista')),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            color: const Color(0xFFFFF8E1),
            child: const Text(
              'Revisá cada ítem. El OCR puede equivocarse, sobre todo con texto manuscrito o fotos torcidas. Corregí lo que haga falta antes de confirmar.',
              style: TextStyle(fontSize: 12.5),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _filas.length,
              itemBuilder: (context, i) {
                final f = _filas[i];
                return Card(
                  child: ListTile(
                    leading: Checkbox(
                      value: f.seleccionada,
                      onChanged: (v) => setState(() => f.seleccionada = v ?? true),
                    ),
                    title: Text(
                      f.descripcion,
                      style: TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                        decoration: f.seleccionada ? null : TextDecoration.lineThrough,
                        color: f.seleccionada ? Colors.black : Colors.grey,
                      ),
                    ),
                    subtitle: Text(
                      f.esSeriado ? 'Equipo seriado · Serie: ${f.serie}' : 'Cantidad: ${f.cantidad ?? "(sin leer)"}',
                      style: const TextStyle(fontSize: 11.5),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.edit_outlined, size: 20),
                      onPressed: () => _editarFila(i),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: ElevatedButton(
              onPressed: _confirmarTodo,
              style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
              child: Text('Confirmar ${_filas.where((f) => f.seleccionada).length} ítem(s)'),
            ),
          ),
        ],
      ),
    );
  }
}
