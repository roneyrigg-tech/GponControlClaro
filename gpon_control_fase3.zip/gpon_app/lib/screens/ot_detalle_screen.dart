// lib/screens/ot_detalle_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/orden_trabajo.dart';
import '../models/tarifa.dart';
import '../services/ot_provider.dart';
import '../services/facturacion_service.dart';
import '../services/database_service.dart';
import '../services/inventario_provider.dart';

class OTDetalleScreen extends StatefulWidget {
  final OrdenTrabajo ot;
  const OTDetalleScreen({super.key, required this.ot});

  @override
  State<OTDetalleScreen> createState() => _OTDetalleScreenState();
}

class _OTDetalleScreenState extends State<OTDetalleScreen> {
  late OrdenTrabajo _ot;

  @override
  void initState() {
    super.initState();
    _ot = widget.ot;
    if (_ot.tarifaBaseId == null) {
      final sugerida = FacturacionService.sugerirTarifaBase(_ot.subtipo, _ot.contratistaId);
      if (sugerida != null) {
        _ot.tarifaBaseId = sugerida.id;
      }
    }
  }

  Future<void> _guardar() async {
    await context.read<OTProvider>().guardar(_ot);
  }

  void _cambiarEstado(EstadoOT nuevo) {
    setState(() => _ot.estadoFlujo = nuevo);
    _guardar();
  }

  void _elegirTarifaBase() async {
    final seleccionada = await showModalBottomSheet<Tarifa>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _SelectorTarifaBase(contratistaId: _ot.contratistaId),
    );
    if (seleccionada != null) {
      setState(() => _ot.tarifaBaseId = seleccionada.id);
      _guardar();
    }
  }

  void _agregarAdicional() async {
    final resultado = await showModalBottomSheet<AdicionalFacturado>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _SelectorAdicional(contratistaId: _ot.contratistaId),
    );
    if (resultado != null) {
      setState(() => _ot.adicionalesFacturados.add(resultado));
      _guardar();
    }
  }

  /// Pregunta al técnico cómo resolver un equipo que aparece
  /// "desinstalado" en el Log de Equipos: ¿fue un cambio en sitio
  /// (equipo defectuoso de fábrica, no llegó a usarse de verdad) o una
  /// avería real (el equipo se dañó en operación)?
  ///
  /// FASE 2 (25/06/2026): ya existe la tabla de equipos rastreados por
  /// número de serie (EquipoSeriado), así que esto SÍ actualiza el
  /// inventario real, además de registrar la resolución en el log de
  /// la OT:
  ///   - vuelveAInventario: la serie pasa a estado "disponible" (vuelve
  ///     a la mochila del técnico, lista para otra instalación).
  ///   - dañado: la serie pasa a estado "dañado" (fuera de circulación
  ///     hasta que se devuelva físicamente a bodega).
  Future<void> _resolverEquipoPendiente(EventoEquipo evento) async {
    final resolucion = await showDialog<ResolucionDesinstalacion>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Text('${evento.tipoEquipo} ${evento.serie}'),
        content: const Text(
          'Este equipo aparece desinstalado en la OT.\n\n'
          '¿Qué pasó realmente?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(
              context,
              ResolucionDesinstalacion.vuelveAInventario,
            ),
            child: const Text('Cambio en sitio\n(vuelve a inventario)',
                textAlign: TextAlign.center),
          ),
          TextButton(
            onPressed: () => Navigator.pop(
              context,
              ResolucionDesinstalacion.danado,
            ),
            child: const Text('Se averió\n(no vuelve a stock)',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFFE8531C))),
          ),
        ],
      ),
    );

    if (resolucion == null) return; // técnico cerró sin elegir

    setState(() => evento.resolucion = resolucion);
    await _guardar();

    // Conecta el efecto real sobre el inventario seriado (Fase 2).
    final inventario = context.read<InventarioProvider>();
    if (resolucion == ResolucionDesinstalacion.vuelveAInventario) {
      await inventario.devolverADisponible(
          _ot.contratistaId, evento.tipoEquipo, evento.serie);
    } else {
      await inventario.marcarDanado(
          _ot.contratistaId, evento.tipoEquipo, evento.serie);
    }

    if (mounted) {
      final mensaje = resolucion == ResolucionDesinstalacion.vuelveAInventario
          ? '${evento.serie}: marcado como cambio en sitio (vuelve a inventario)'
          : '${evento.serie}: marcado como dañado';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(mensaje)),
      );
    }
  }

  Future<void> _liquidar() async {
    // Guardrail (Fase 1): no tiene sentido liquidar/facturar una OT que
    // todavía tiene equipos desinstalados sin revisar — el técnico
    // podría olvidarse de marcarlos después. Se advierte pero no se
    // bloquea del todo, por si el técnico de verdad necesita liquidar
    // ya y resolverlo más tarde.
    final pendientes = _ot.logEquipos
        .where((e) =>
            e.tipo == TipoEventoEquipo.desinstalado && e.resolucion == null)
        .length;

    if (pendientes > 0) {
      final continuar = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Equipos sin revisar'),
          content: Text(
            pendientes == 1
                ? 'Hay 1 equipo desinstalado en esta OT que todavía no marcaste como "cambio en sitio" o "dañado". ¿Liquidar igual?'
                : 'Hay $pendientes equipos desinstalados en esta OT que todavía no marcaste como "cambio en sitio" o "dañado". ¿Liquidar igual?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Revisar primero'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Liquidar igual'),
            ),
          ],
        ),
      );
      if (continuar != true) return;
    }

    final resultado = FacturacionService.calcular(_ot);

    final confirmar = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Confirmar liquidación'),
        content: Text(
          'Se registrará un monto por facturar de\n'
          '₡${resultado.totalGeneral.toStringAsFixed(2)}\n\n'
          'para la OT ${_ot.numeroOT}.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Confirmar'),
          ),
        ],
      ),
    );

    if (confirmar != true) return;

    await DatabaseService.instance.registrarLiquidacion(
      otId: _ot.id,
      contratistaId: _ot.contratistaId,
      monto: resultado.totalGeneral,
      descripcion: 'OT ${_ot.numeroOT} — ${_ot.nombreCliente}',
    );

    _cambiarEstado(EstadoOT.liquidado);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('OT liquidada y agregada a "Por Facturar" ✓')),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final resultado = FacturacionService.calcular(_ot);
    final tarifarioDeEstaOT = tarifarioDe(_ot.contratistaId);
    final tarifaBase = _ot.tarifaBaseId != null
        ? tarifarioDeEstaOT.firstWhere((t) => t.id == _ot.tarifaBaseId)
        : null;

    return Scaffold(
      appBar: AppBar(title: Text(_ot.numeroOT)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _SeccionInfo(ot: _ot),

          if (_ot.logEquipos.isNotEmpty) ...[
            const SizedBox(height: 16),
            _SeccionLogEquipos(
              ot: _ot,
              onResolver: _resolverEquipoPendiente,
            ),
          ],

          const SizedBox(height: 16),

          const Text('Estado de la visita', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _SelectorEstado(estadoActual: _ot.estadoFlujo, onCambio: _cambiarEstado),

          const SizedBox(height: 20),
          const Text('Tarifa base (combo)', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              title: Text(tarifaBase?.descripcion ?? 'Sin seleccionar'),
              subtitle: tarifaBase != null
                  ? Text('₡${tarifaBase.valor.toStringAsFixed(2)}')
                  : const Text('Tocá para elegir el combo correcto'),
              trailing: const Icon(Icons.edit),
              onTap: _elegirTarifaBase,
            ),
          ),

          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Adicionales', style: TextStyle(fontWeight: FontWeight.bold)),
              TextButton.icon(
                onPressed: _agregarAdicional,
                icon: const Icon(Icons.add),
                label: const Text('Agregar'),
              ),
            ],
          ),
          if (_ot.adicionalesFacturados.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('Sin adicionales registrados', style: TextStyle(color: Colors.grey)),
            )
          else
            ..._ot.adicionalesFacturados.map((a) {
              final t = tarifarioDeEstaOT.firstWhere((tt) => tt.id == a.tarifaId);
              return Card(
                child: ListTile(
                  title: Text(t.descripcion),
                  subtitle: Text('Cantidad: ${a.cantidad} ${t.unidad}'),
                  trailing: Text(
                    '₡${a.subtotal.toStringAsFixed(2)}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              );
            }),

          const SizedBox(height: 20),
          Card(
            color: const Color(0xFF14213D),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _filaTotal('Tarifa base', resultado.totalBase),
                  _filaTotal('Adicionales', resultado.totalAdicionales),
                  const Divider(color: Colors.white24),
                  _filaTotal('Total a facturar', resultado.totalGeneral, destacado: true),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),
          if (_ot.estadoFlujo != EstadoOT.liquidado)
            ElevatedButton.icon(
              onPressed: _liquidar,
              icon: const Icon(Icons.check_circle_outline),
              label: const Text('Liquidar y enviar a "Por Facturar"'),
            )
          else
            const Center(
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  '✓ Esta OT ya fue liquidada',
                  style: TextStyle(color: Color(0xFF1E8449), fontWeight: FontWeight.bold),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _filaTotal(String label, double valor, {bool destacado = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.white,
              fontWeight: destacado ? FontWeight.bold : FontWeight.normal,
              fontSize: destacado ? 16 : 13,
            ),
          ),
          Text(
            '₡${valor.toStringAsFixed(2)}',
            style: TextStyle(
              color: Colors.white,
              fontWeight: destacado ? FontWeight.bold : FontWeight.normal,
              fontSize: destacado ? 16 : 13,
            ),
          ),
        ],
      ),
    );
  }
}

class _SeccionLogEquipos extends StatelessWidget {
  final OrdenTrabajo ot;
  final void Function(EventoEquipo) onResolver;
  const _SeccionLogEquipos({required this.ot, required this.onResolver});

  @override
  Widget build(BuildContext context) {
    final pendientes = ot.logEquipos
        .where((e) =>
            e.tipo == TipoEventoEquipo.desinstalado && e.resolucion == null)
        .toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Equipos (Log de la OT)',
            style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),

        if (pendientes.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF0EA),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE8531C).withOpacity(0.3)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.warning_amber_rounded, color: Color(0xFFE8531C)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    pendientes.length == 1
                        ? 'Tenés 1 equipo desinstalado pendiente de revisar. Tocalo abajo para indicar qué pasó.'
                        : 'Tenés ${pendientes.length} equipos desinstalados pendientes de revisar. Tocá cada uno abajo para indicar qué pasó.',
                    style: const TextStyle(fontSize: 12.5, color: Color(0xFFE8531C)),
                  ),
                ),
              ],
            ),
          ),

        ...ot.logEquipos.map((evento) => _FilaEvento(
              evento: evento,
              onTap: (evento.tipo == TipoEventoEquipo.desinstalado &&
                      evento.resolucion == null)
                  ? () => onResolver(evento)
                  : null,
            )),
      ],
    );
  }
}

class _FilaEvento extends StatelessWidget {
  final EventoEquipo evento;
  final VoidCallback? onTap; // null si no requiere acción (instalado, o ya resuelto)
  const _FilaEvento({required this.evento, this.onTap});

  @override
  Widget build(BuildContext context) {
    final esDesinstalado = evento.tipo == TipoEventoEquipo.desinstalado;
    final pendiente = esDesinstalado && evento.resolucion == null;

    Color colorBadge;
    String textoBadge;
    if (!esDesinstalado) {
      colorBadge = const Color(0xFF1E8449);
      textoBadge = 'INSTALADO';
    } else if (pendiente) {
      colorBadge = const Color(0xFFE8531C);
      textoBadge = 'REVISAR';
    } else if (evento.resolucion == ResolucionDesinstalacion.vuelveAInventario) {
      colorBadge = const Color(0xFF0B5FFF);
      textoBadge = 'CAMBIO EN SITIO';
    } else {
      colorBadge = const Color(0xFF7A1F1F);
      textoBadge = 'DAÑADO';
    }

    return Card(
      child: ListTile(
        dense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        title: Text(
          '${evento.tipoEquipo} ${evento.serie}',
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5),
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: colorBadge.withOpacity(0.12),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            textoBadge,
            style: TextStyle(
              color: colorBadge,
              fontWeight: FontWeight.bold,
              fontSize: 10.5,
            ),
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}

class _SeccionInfo extends StatelessWidget {
  final OrdenTrabajo ot;
  const _SeccionInfo({required this.ot});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _fila('Cliente', ot.nombreCliente),
            _fila('Subtipo', ot.subtipo),
            _fila('Plan', ot.plan),
            _fila('Dirección', ot.direccion),
            _fila('N° Solicitud', ot.numeroSolicitud),
            _fila('N° Facturación', ot.numeroFacturacion),
          ],
        ),
      ),
    );
  }

  Widget _fila(String label, String valor) {
    if (valor.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(color: Colors.black, fontSize: 13),
          children: [
            TextSpan(text: '$label: ', style: const TextStyle(fontWeight: FontWeight.bold)),
            TextSpan(text: valor),
          ],
        ),
      ),
    );
  }
}

class _SelectorEstado extends StatelessWidget {
  final EstadoOT estadoActual;
  final void Function(EstadoOT) onCambio;
  const _SelectorEstado({required this.estadoActual, required this.onCambio});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      children: EstadoOT.values.map((estado) {
        final seleccionado = estado == estadoActual;
        return ChoiceChip(
          label: Text(_texto(estado)),
          selected: seleccionado,
          onSelected: (_) => onCambio(estado),
        );
      }).toList(),
    );
  }

  String _texto(EstadoOT estado) {
    switch (estado) {
      case EstadoOT.pendiente:
        return 'Pendiente';
      case EstadoOT.enRuta:
        return 'En ruta';
      case EstadoOT.instalado:
        return 'Instalado';
      case EstadoOT.liquidado:
        return 'Liquidado';
    }
  }
}

class _SelectorTarifaBase extends StatelessWidget {
  final String contratistaId;
  const _SelectorTarifaBase({required this.contratistaId});

  @override
  Widget build(BuildContext context) {
    final combos = tarifarioDe(contratistaId)
        .where((t) => t.tipo == TipoTarifa.instalacionAbonado)
        .toList();

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Elegí el combo instalado', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            if (combos.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  'Este contratista todavía no tiene tarifario cargado.',
                  style: TextStyle(color: Colors.grey),
                ),
              ),
            ...combos.map((t) => ListTile(
                  title: Text(t.descripcion),
                  trailing: Text('₡${t.valor.toStringAsFixed(2)}'),
                  onTap: () => Navigator.pop(context, t),
                )),
          ],
        ),
      ),
    );
  }
}

class _SelectorAdicional extends StatefulWidget {
  final String contratistaId;
  const _SelectorAdicional({required this.contratistaId});

  @override
  State<_SelectorAdicional> createState() => _SelectorAdicionalState();
}

class _SelectorAdicionalState extends State<_SelectorAdicional> {
  Tarifa? _tarifaSeleccionada;
  final TextEditingController _cantidadCtrl = TextEditingController(text: '1');

  @override
  void initState() {
    super.initState();
    // Refresca el subtotal mostrado en vivo mientras el técnico escribe
    // la cantidad de metros (necesario para que el preview de la regla
    // de excedente se actualice sin esperar a otro setState externo).
    _cantidadCtrl.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _cantidadCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final adicionales = tarifarioDe(widget.contratistaId)
        .where((t) => t.tipo != TipoTarifa.instalacionAbonado)
        .toList();

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Agregar adicional', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            DropdownButtonFormField<Tarifa>(
              value: _tarifaSeleccionada,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Concepto'),
              items: adicionales
                  .map((t) => DropdownMenuItem(
                        value: t,
                        child: Text(
                          '${t.descripcion} (₡${t.valor.toStringAsFixed(2)}/${t.unidad})',
                          overflow: TextOverflow.ellipsis,
                        ),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _tarifaSeleccionada = v),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _cantidadCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'Cantidad${_tarifaSeleccionada != null ? ' (${_tarifaSeleccionada!.unidad})' : ''}',
                // CORRECCIÓN (25/06/2026): cuando la tarifa tiene umbral de
                // metros incluidos (ej. metro_utp con 5m, metro_drop_fo con
                // 100m), se le aclara al técnico que debe ingresar el TOTAL
                // de metros instalados, no solo el excedente — el cálculo
                // se encarga de restar el umbral automáticamente.
                helperText: (_tarifaSeleccionada?.umbralMetros != null)
                    ? 'Ingresá el total de metros instalados. Los primeros ${_tarifaSeleccionada!.umbralMetros!.toStringAsFixed(0)}m están incluidos y no se cobran.'
                    : null,
                helperMaxLines: 2,
              ),
            ),
            if (_tarifaSeleccionada?.umbralMetros != null) ...[
              const SizedBox(height: 8),
              Builder(builder: (context) {
                final cantidad = double.tryParse(_cantidadCtrl.text) ?? 0;
                final subtotal =
                    _tarifaSeleccionada!.calcularSubtotalConUmbral(cantidad);
                return Text(
                  'Subtotal a cobrar: ₡${subtotal.toStringAsFixed(2)}',
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                );
              }),
            ],
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _tarifaSeleccionada == null
                  ? null
                  : () {
                      final cantidad = double.tryParse(_cantidadCtrl.text) ?? 0;
                      if (cantidad <= 0) return;
                      // CORRECCIÓN (25/06/2026): antes se calculaba
                      // tarifa.valor * cantidad sin restar el umbral de
                      // metros incluidos, lo que sobrecobraba en cada
                      // instalación de UTP/fibra. Ahora se usa el método
                      // del modelo que resta el umbral cuando aplica (y
                      // que se comporta igual que antes para tarifas sin
                      // umbral, como metro_canaleta).
                      final subtotal = _tarifaSeleccionada!
                          .calcularSubtotalConUmbral(cantidad);
                      Navigator.pop(
                        context,
                        AdicionalFacturado(
                          tarifaId: _tarifaSeleccionada!.id,
                          cantidad: cantidad,
                          subtotal: subtotal,
                        ),
                      );
                    },
              child: const Text('Agregar'),
            ),
          ],
        ),
      ),
    );
  }
}
