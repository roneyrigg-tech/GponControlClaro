// lib/models/feriado.dart
//
// FASE 3 (26/06/2026): lista fija de feriados oficiales de Costa Rica,
// usada para calcular el cierre de quincena (días hábiles 15/30,
// corriendo al día hábil anterior si la fecha de cierre cae en fin de
// semana o feriado).
//
// Roney confirmó que prefiere una lista fija que se actualiza a mano
// cada año, en vez de un cálculo automático de fechas móviles (Semana
// Santa, etc.). Por eso esta lista vive en una tabla editable
// (feriados en SQLite) con una pantalla simple para agregar/quitar
// fechas — no hay lógica de calendario litúrgico en el código.

class Feriado {
  final String id; // usamos la fecha en formato yyyy-MM-dd como id
  final DateTime fecha;
  final String nombre;

  Feriado({required this.fecha, required this.nombre}) : id = _idDesdeFecha(fecha);

  static String _idDesdeFecha(DateTime f) =>
      '${f.year.toString().padLeft(4, '0')}-${f.month.toString().padLeft(2, '0')}-${f.day.toString().padLeft(2, '0')}';

  Map<String, dynamic> toMap() => {
        'id': id,
        'fecha': fecha.toIso8601String(),
        'nombre': nombre,
      };

  factory Feriado.fromMap(Map<String, dynamic> map) => Feriado(
        fecha: DateTime.parse(map['fecha'] as String),
        nombre: map['nombre'] as String,
      );
}

/// Feriados oficiales de Costa Rica para 2026, precargados al crear la
/// base de datos. Roney puede agregar, editar o quitar fechas desde la
/// pantalla de Feriados — esta lista es solo el punto de partida.
///
/// Fuente: comunicado oficial del MTSS para 2026 (verificado 26/06/2026).
/// IMPORTANTE: para el año 2026 no hay ley vigente que traslade
/// feriados al lunes más cercano — todas las fechas se mantienen en su
/// día original, aunque caigan en fin de semana. Esto incluye 4
/// feriados que en 2026 caen sábado o domingo (11 de abril, 25 de
/// julio, 2 de agosto, 15 de agosto): de todas formas se incluyen en
/// esta lista porque siguen contando como feriado para el cálculo de
/// cierre de quincena, por si el día 15 o 30 cae justo en una de esas
/// fechas un año futuro en que sí caigan en día de semana.
///
/// Esta lista cubre los 12 feriados oficiales (9 de pago obligatorio +
/// 3 de pago no obligatorio); para años siguientes, Roney debe
/// actualizar las fechas desde la pantalla de Feriados, ya que Jueves
/// y Viernes Santo son de fecha móvil cada año.
final List<Feriado> feriadosCostaRicaIniciales = [
  Feriado(fecha: DateTime(2026, 1, 1), nombre: 'Año Nuevo'),
  Feriado(fecha: DateTime(2026, 4, 2), nombre: 'Jueves Santo'),
  Feriado(fecha: DateTime(2026, 4, 3), nombre: 'Viernes Santo'),
  Feriado(fecha: DateTime(2026, 4, 11), nombre: 'Día de Juan Santamaría'),
  Feriado(fecha: DateTime(2026, 5, 1), nombre: 'Día Internacional del Trabajo'),
  Feriado(fecha: DateTime(2026, 7, 25), nombre: 'Anexión del Partido de Nicoya'),
  Feriado(fecha: DateTime(2026, 8, 2), nombre: 'Día de Nuestra Señora de los Ángeles'),
  Feriado(fecha: DateTime(2026, 8, 15), nombre: 'Día de la Madre'),
  Feriado(fecha: DateTime(2026, 8, 31), nombre: 'Día de la Persona Negra y la Cultura Afrocostarricense'),
  Feriado(fecha: DateTime(2026, 9, 15), nombre: 'Día de la Independencia'),
  Feriado(fecha: DateTime(2026, 12, 1), nombre: 'Día de la Abolición del Ejército'),
  Feriado(fecha: DateTime(2026, 12, 25), nombre: 'Navidad'),
];
