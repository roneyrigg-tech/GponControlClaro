// lib/models/tarifa.dart
//
// Modelo de tarifas de mano de obra.
//
// FASE 3 (26/06/2026): CORRECCIÓN sobre el diseño de Fase 1. En Fase 1
// se quitó contratistaId de Tarifa porque, al revisar el Excel real
// (TARIFAS_CONTRATISTAS_2025.xlsx), CARSO y COLSAGO resultaron tener
// los mismos montos — pero eso fue una coincidencia de ESOS DOS
// contratistas, no una regla general del sistema. Roney aclaró
// (26/06/2026) que una contrata futura podría tener un tarifario
// completamente distinto, así que el diseño correcto es: cada
// contratista tiene SU PROPIO tarifario independiente (su propio
// "árbol", en palabras de Roney) — inventario, equipos, OTs Y AHORA
// TAMBIÉN tarifario, todos aislados por contratistaId sin excepciones
// compartidas. Que CARSO y COLSAGO tengan hoy los mismos montos es
// solo el valor inicial de sus listas, no una regla del modelo.
//
// Por eso Tarifa vuelve a tener contratistaId, y en vez de una sola
// lista tarifarioClaro hay un mapa tarifariosPorContratista indexado
// por contratistaId. Agregar una contrata nueva en el futuro es crear
// su propia entrada en ese mapa (o, más adelante, su propia fila en
// una tabla SQLite editable) sin tocar las de CARSO/COLSAGO.
//
// También se mantiene lo confirmado en Fase 1: las filas "Instalación
// de metro adicional cable UTP" (₡48.852/m) e "Instalación de metro
// adicional drop FO" (₡24.426/m) YA SON la regla de excedente sobre
// metraje (umbral 5m para cable de TV/UTP, 100m para fibra óptica).
//
// Fuente de los montos iniciales: TARIFAS_CONTRATISTAS_2025.xlsx
// (subido 25/06/2026), cargados igual para CARSO y COLSAGO porque así
// venían en ese archivo — no porque el sistema los obligue a coincidir.

class Tarifa {
  final String id;
  final String contratistaId; // 'carso' | 'colsago' | ... (Fase 3)
  final String descripcion;
  final String unidad; // 'UN' o 'M'
  final double valor;
  final TipoTarifa tipo;

  // Solo aplica a tarifas medidas por metro con umbral incluido (ej.
  // metroAdicional): cantidad de metros incluidos sin costo antes de
  // empezar a cobrar el excedente. null para tarifas sin umbral (la
  // mayoría son por unidad, 'UN', y se cobran completas siempre).
  final double? umbralMetros;

  const Tarifa({
    required this.id,
    required this.contratistaId,
    required this.descripcion,
    required this.unidad,
    required this.valor,
    required this.tipo,
    this.umbralMetros,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'contratistaId': contratistaId,
        'descripcion': descripcion,
        'unidad': unidad,
        'valor': valor,
        'tipo': tipo.name,
        'umbralMetros': umbralMetros,
      };

  factory Tarifa.fromMap(Map<String, dynamic> map) => Tarifa(
        id: map['id'] as String,
        // Compatibilidad con filas guardadas en Fase 1-2 (sin
        // contratistaId, cuando el tarifario era único): se asumen de
        // CARSO si falta el dato.
        contratistaId: (map['contratistaId'] as String?) ?? 'carso',
        descripcion: map['descripcion'] as String,
        unidad: map['unidad'] as String,
        valor: (map['valor'] as num).toDouble(),
        tipo: TipoTarifa.values.firstWhere((t) => t.name == map['tipo']),
        umbralMetros: (map['umbralMetros'] as num?)?.toDouble(),
      );

  /// Calcula el subtotal a cobrar para una cantidad de metros instalados
  /// en una tarifa con umbral (ej. metroAdicional). Solo se paga el
  /// excedente sobre el umbral incluido.
  /// Ej: umbral=5, valor=48.852, metros=8 -> (8-5)*48.852 = 146.556
  /// Si metros <= umbral, el subtotal es 0.
  double calcularSubtotalConUmbral(double metrosInstalados) {
    final umbral = umbralMetros ?? 0;
    final excedente = metrosInstalados - umbral;
    if (excedente <= 0) return 0;
    return excedente * valor;
  }
}

enum TipoTarifa {
  instalacionAbonado, // combos base (One/Two/Triple Play)
  adicionalPrimeraVisita,
  adicionalSegundaVisita,
  metroAdicional, // se cobra solo el excedente sobre umbralMetros
  cableadoCanaleta,
  trasladoExterno,
  trasladoInterno,
  reubicacion,
  sustitucionEquipo,
  reparacionMasiva,
  retiroEquipos,
  otro,
}

/// Tarifario de CARSO, vigente desde la actualización del 25/06/2026
/// (ver TARIFAS_CONTRATISTAS_2025.xlsx).
///
/// NOTA: esto vive como lista hardcodeada por ahora. La idea a futuro
/// es moverlo a una tabla SQLite editable desde la app, para que
/// cuando Claro actualice el tarifario (cada ~6 meses) Roney pueda
/// cargarlo sin esperar una nueva versión de la app. Por ahora se
/// mantiene en código y se actualiza el comentario de fecha cuando
/// cambie.
final List<Tarifa> tarifarioCarso = [
  // ---- Instalación de abonados (combos base) ----
  Tarifa(
    id: 'inst_one_voz',
    contratistaId: 'carso',
    descripcion: 'Instalación abonados (One Play/Voz)',
    unidad: 'UN',
    valor: 16000.00,
    tipo: TipoTarifa.instalacionAbonado,
  ),
  Tarifa(
    id: 'inst_one_internet',
    contratistaId: 'carso',
    descripcion: 'Instalación abonados (One Play/Internet)',
    unidad: 'UN',
    valor: 16000.00,
    tipo: TipoTarifa.instalacionAbonado,
  ),
  Tarifa(
    id: 'inst_one_tv',
    contratistaId: 'carso',
    descripcion: 'Instalación abonados (One Play/Televisión)',
    unidad: 'UN',
    valor: 16000.00,
    tipo: TipoTarifa.instalacionAbonado,
  ),
  Tarifa(
    id: 'inst_two_voz_internet',
    contratistaId: 'carso',
    descripcion: 'Instalación abonados (Two Play/Voz_Internet)',
    unidad: 'UN',
    valor: 18000.00,
    tipo: TipoTarifa.instalacionAbonado,
  ),
  Tarifa(
    id: 'inst_two_internet_tv',
    contratistaId: 'carso',
    descripcion: 'Instalación abonados (Two Play/Internet_Televisión)',
    unidad: 'UN',
    valor: 18000.00,
    tipo: TipoTarifa.instalacionAbonado,
  ),
  Tarifa(
    id: 'inst_two_tv_voz',
    contratistaId: 'carso',
    descripcion: 'Instalación abonados (Two Play/Televisión Voz)',
    unidad: 'UN',
    valor: 18000.00,
    tipo: TipoTarifa.instalacionAbonado,
  ),
  Tarifa(
    id: 'inst_triple',
    contratistaId: 'carso',
    descripcion:
        'Instalación abonados (Triple Play/Internet_Televisión_Voz)',
    unidad: 'UN',
    valor: 19500.00,
    tipo: TipoTarifa.instalacionAbonado,
  ),

  // ---- Adicionales en la instalación ----
  Tarifa(
    id: 'inst_switch',
    contratistaId: 'carso',
    descripcion: 'Instalación de Switch',
    unidad: 'UN',
    valor: 2287.00,
    tipo: TipoTarifa.adicionalPrimeraVisita,
  ),
  Tarifa(
    id: 'inst_ott_primera',
    contratistaId: 'carso',
    descripcion: 'Instalación de OTT adicional en primera visita',
    unidad: 'UN',
    valor: 2065.50,
    tipo: TipoTarifa.adicionalPrimeraVisita,
  ),
  Tarifa(
    id: 'inst_segunda_voz',
    contratistaId: 'carso',
    descripcion: 'Instalación de servicio adicional en segunda visita (Voz)',
    unidad: 'UN',
    valor: 4383.00,
    tipo: TipoTarifa.adicionalSegundaVisita,
  ),
  Tarifa(
    id: 'inst_segunda_internet',
    contratistaId: 'carso',
    descripcion:
        'Instalación de servicio adicional en segunda visita (Internet)',
    unidad: 'UN',
    valor: 4523.00,
    tipo: TipoTarifa.adicionalSegundaVisita,
  ),
  Tarifa(
    id: 'inst_segunda_tv',
    contratistaId: 'carso',
    descripcion:
        'Instalación de servicio adicional en segunda visita (Televisión)',
    unidad: 'UN',
    valor: 4523.00,
    tipo: TipoTarifa.adicionalSegundaVisita,
  ),

  // ---- Metros adicionales de cable (excedente sobre umbral incluido) ----
  Tarifa(
    id: 'metro_utp',
    contratistaId: 'carso',
    descripcion: 'Instalación de metro adicional cable UTP',
    unidad: 'M',
    valor: 48.852,
    tipo: TipoTarifa.metroAdicional,
    umbralMetros: 5.0, // primeros 5m de cable de caja TV/UTP incluidos
  ),
  Tarifa(
    id: 'metro_drop_fo',
    contratistaId: 'carso',
    descripcion: 'Instalación de metro adicional drop FO',
    unidad: 'M',
    valor: 24.426,
    tipo: TipoTarifa.metroAdicional,
    umbralMetros: 100.0, // primeros 100m de fibra óptica incluidos
  ),
  Tarifa(
    id: 'cableado_canaleta',
    contratistaId: 'carso',
    descripcion: 'Instalación de cableado UTP (Ethernet) en canaleta',
    unidad: 'UN',
    valor: 128.367,
    tipo: TipoTarifa.cableadoCanaleta,
  ),
  Tarifa(
    id: 'metro_canaleta',
    contratistaId: 'carso',
    descripcion: 'Metro adicional de cableado UTP en canaleta',
    unidad: 'M',
    valor: 65.133,
    tipo: TipoTarifa.cableadoCanaleta,
  ),

  // ---- Traslado de servicio externo ----
  Tarifa(
    id: 'traslado_ext_one_voz',
    contratistaId: 'carso',
    descripcion: 'Traslado de Servicio Externo One Play Voz',
    unidad: 'UN',
    valor: 10668.00,
    tipo: TipoTarifa.trasladoExterno,
  ),
  Tarifa(
    id: 'traslado_ext_one_internet',
    contratistaId: 'carso',
    descripcion: 'Traslado de Servicio Externo One Play Internet',
    unidad: 'UN',
    valor: 10668.00,
    tipo: TipoTarifa.trasladoExterno,
  ),
  Tarifa(
    id: 'traslado_ext_one_tv',
    contratistaId: 'carso',
    descripcion: 'Traslado de Servicio Externo One Play Televisión (IPTV)',
    unidad: 'UN',
    valor: 10668.675,
    tipo: TipoTarifa.trasladoExterno,
  ),
  Tarifa(
    id: 'traslado_ext_two_voz_internet',
    contratistaId: 'carso',
    descripcion: 'Traslado de Servicio Externo Two Play Voz e Internet',
    unidad: 'UN',
    valor: 13800.00,
    tipo: TipoTarifa.trasladoExterno,
  ),
  Tarifa(
    id: 'traslado_ext_two_voz_tv',
    contratistaId: 'carso',
    descripcion:
        'Traslado de Servicio Externo Two Play Voz y Televisión (IPTV)',
    unidad: 'UN',
    valor: 15600.00,
    tipo: TipoTarifa.trasladoExterno,
  ),
  Tarifa(
    id: 'traslado_ext_two_internet_tv',
    contratistaId: 'carso',
    descripcion:
        'Traslado de Servicio Externo Two Play Internet y Televisión (IPTV)',
    unidad: 'UN',
    valor: 15600.00,
    tipo: TipoTarifa.trasladoExterno,
  ),
  Tarifa(
    id: 'traslado_ext_triple',
    contratistaId: 'carso',
    descripcion:
        'Traslado de Servicio Externo Triple Play: Internet, Televisión (IPTV) y Voz',
    unidad: 'UN',
    valor: 15600.00,
    tipo: TipoTarifa.trasladoExterno,
  ),

  // ---- Traslado / reubicación de servicio interno ----
  Tarifa(
    id: 'traslado_int_acometida',
    contratistaId: 'carso',
    descripcion:
        'Traslado de Servicio Interno (Reubicación de acometida y/o ONT)',
    unidad: 'UN',
    valor: 7074.415,
    tipo: TipoTarifa.trasladoInterno,
  ),
  Tarifa(
    id: 'traslado_int_ott',
    contratistaId: 'carso',
    descripcion: 'Traslado de Servicio Interno (Reubicación de OTT)',
    unidad: 'UN',
    valor: 7074.415,
    tipo: TipoTarifa.trasladoInterno,
  ),
  Tarifa(
    id: 'reubicacion_ott_switch',
    contratistaId: 'carso',
    descripcion: 'Reubicación de OTT y/o Switch',
    unidad: 'UN',
    valor: 2634.66,
    tipo: TipoTarifa.reubicacion,
  ),

  // ---- Sustitución / instalación de equipos ----
  Tarifa(
    id: 'sustitucion_equipo',
    contratistaId: 'carso',
    descripcion: 'Sustitución de equipos por cambio de tecnología',
    unidad: 'UN',
    valor: 5328.445,
    tipo: TipoTarifa.sustitucionEquipo,
  ),
  Tarifa(
    id: 'inst_equipo_mesh',
    contratistaId: 'carso',
    descripcion: 'Instalación de equipo mesh',
    unidad: 'UN',
    valor: 5100.00,
    tipo: TipoTarifa.sustitucionEquipo,
  ),

  // ---- Alcances reparaciones servicios masivos ----
  // Incluye: revisión/activación/configuración de equipos Claro (TV,
  // telefonía, internet); revisión NAP-Roseta-ONT; revisión de
  // conexiones y cableado de acometida; cambios de roseta óptica,
  // conectores/crimpado; sustitución de patchcord, cable de abonado,
  // cables Ethernet con conectores; cambio de ONT/OTT (retiro,
  // recolección, desinstalación, instalación, configuración,
  // activación); mediciones eléctricas/ópticas y carga en sistemas
  // de Claro. Pago único que cubre todo eso por visita de reparación.
  Tarifa(
    id: 'reparacion_masiva_fttx',
    contratistaId: 'carso',
    descripcion: 'Reparación de abonados masivos (FTTX)',
    unidad: 'UN',
    valor: 6529.625,
    tipo: TipoTarifa.reparacionMasiva,
  ),

  // ---- Retiro de equipos ----
  Tarifa(
    id: 'retiro_migracion_equipos_multimedia',
    contratistaId: 'carso',
    descripcion: 'Retiro/Migración Equipos Multimedia FTTX',
    unidad: 'UN',
    valor: 5077.435,
    tipo: TipoTarifa.retiroEquipos,
  ),
  Tarifa(
    id: 'retiro_migracion_cableado_aeroducto',
    contratistaId: 'carso',
    descripcion: 'Retiro/Migración Cableado Aeroducto FTTX',
    unidad: 'UN',
    valor: 5590.34,
    tipo: TipoTarifa.retiroEquipos,
  ),
];

/// Tarifario de COLSAGO.
///
/// FASE 3 (26/06/2026): se genera COPIANDO los montos de tarifarioCarso
/// porque, según el Excel real (TARIFAS_CONTRATISTAS_2025.xlsx), hoy
/// coinciden exactamente. Esto es una decisión de DATOS (ambos
/// tarifarios arrancan iguales), no una limitación del modelo: cada
/// Tarifa de esta lista es su propia instancia independiente con
/// contratistaId='colsago' e id con prefijo 'colsago_' (para que no
/// choquen como primary key con las de CARSO si en el futuro se
/// guardan en SQLite). Se puede editar esta lista sin afectar
/// tarifarioCarso en absoluto — son árboles separados desde ahora.
final List<Tarifa> tarifarioColsago = tarifarioCarso
    .map((t) => Tarifa(
          id: 'colsago_${t.id}',
          contratistaId: 'colsago',
          descripcion: t.descripcion,
          unidad: t.unidad,
          valor: t.valor,
          tipo: t.tipo,
          umbralMetros: t.umbralMetros,
        ))
    .toList();

/// Mapa de todos los tarifarios conocidos, indexado por contratistaId.
/// Este es el punto único de acceso para que la UI y los servicios
/// busquen "el tarifario de este contratista" sin tener que conocer
/// los nombres de cada lista individual.
///
/// Agregar una contrata nueva en el futuro es agregar una entrada
/// nueva aquí (su propia lista de Tarifa, con su propio contratistaId)
/// — no requiere tocar las entradas de 'carso' ni 'colsago'.
final Map<String, List<Tarifa>> tarifariosPorContratista = {
  'carso': tarifarioCarso,
  'colsago': tarifarioColsago,
};

/// Devuelve el tarifario del contratista indicado, o una lista vacía
/// si no hay tarifario configurado para ese contratistaId (ej. una
/// contrata nueva agregada desde la app que todavía no tiene precios
/// cargados).
List<Tarifa> tarifarioDe(String contratistaId) =>
    tarifariosPorContratista[contratistaId] ?? [];

