// lib/models/articulo_inventario.dart
//
// Modelo de inventario.
//
// FASE 2 (25/06/2026): se extiende el modelo original (solo
// consumibles por cantidad) para soportar dos tipos de ítem, según lo
// que se ve en la hoja real de entrega de materiales (foto de COLSAGO,
// 22/06/2026):
//
//   1. CONSUMIBLE: se controla por cantidad total (tensores, cable UTP,
//      conectores, maha dedos, tape, etc.). Es lo que ya existía.
//
//   2. SERIADO: equipos con número de serie único e individual (ONT,
//      MESH, STB) que hay que trazar uno por uno — qué serie específica
//      quedó instalada en cuál cliente, cuáles están disponibles en la
//      mochila del técnico, cuáles se dañaron. Cada serie es su propia
//      fila (ver EquipoSeriado), no un número agregado.
//
// Catálogos separados por contratista (confirmado 25/06/2026): CARSO y
// COLSAGO entregan materiales por separado aunque el nombre coincida
// (ej. "TENSORES" de CARSO y "TENSORES" de COLSAGO son stocks distintos),
// así que ArticuloInventario y EquipoSeriado llevan contratistaId.

enum TipoArticulo { consumible, seriado }

class ArticuloInventario {
  final String id;
  final String contratistaId; // 'carso' | 'colsago'
  final String codigo; // código del contratista si lo tiene, o '' si no aplica
  final String nombre; // ej. "CABLE OPTICO MOAVD 1 FIBRA", "ONT", "TENSORES"
  final TipoArticulo tipo;

  // Solo aplica a tipo == consumible. Para tipo == seriado, la cantidad
  // disponible real se calcula contando los EquipoSeriado en estado
  // disponible (ver InventarioProvider), así que estos campos quedan
  // en 0 y no se usan directamente.
  double cantidadDisponible;
  double stockMinimo;
  final String unidad; // 'MTS', 'U', 'UD', 'UN' — solo relevante si consumible

  ArticuloInventario({
    required this.id,
    String? contratistaId,
    required this.codigo,
    required this.nombre,
    TipoArticulo? tipo,
    required this.cantidadDisponible,
    required this.stockMinimo,
    required this.unidad,
  })  : contratistaId = contratistaId ?? 'carso',
        tipo = tipo ?? TipoArticulo.consumible;

  bool get enAlertaCritica =>
      tipo == TipoArticulo.consumible && cantidadDisponible < stockMinimo;

  Map<String, dynamic> toMap() => {
        'id': id,
        'contratistaId': contratistaId,
        'codigo': codigo,
        'nombre': nombre,
        'tipo': tipo.name,
        'cantidadDisponible': cantidadDisponible,
        'stockMinimo': stockMinimo,
        'unidad': unidad,
      };

  factory ArticuloInventario.fromMap(Map<String, dynamic> map) =>
      ArticuloInventario(
        id: map['id'] as String,
        // Compatibilidad con filas de antes de Fase 2 (sin contratistaId
        // ni tipo): se asumen de CARSO y consumibles, que es lo único
        // que existía hasta ahora.
        contratistaId: (map['contratistaId'] as String?) ?? 'carso',
        codigo: map['codigo'] as String,
        nombre: map['nombre'] as String,
        tipo: map['tipo'] == null
            ? TipoArticulo.consumible
            : TipoArticulo.values.firstWhere((t) => t.name == map['tipo']),
        cantidadDisponible: (map['cantidadDisponible'] as num).toDouble(),
        stockMinimo: (map['stockMinimo'] as num).toDouble(),
        unidad: map['unidad'] as String,
      );
}

/// Estado de un equipo individual con número de serie.
enum EstadoEquipoSeriado {
  disponible, // en la mochila del técnico, listo para instalar
  instalado, // ya colocado en un cliente
  danado, // averiado, fuera de circulación hasta devolverlo a bodega
  devuelto, // devuelto a bodega (ej. equipo dañado ya entregado de vuelta)
}

/// Un equipo individual rastreado por número de serie (ONT, MESH, STB).
/// Cada fila es UN equipo físico, no una cantidad agregada.
class EquipoSeriado {
  final String id; // usamos la serie misma como id, es única por contratista
  final String contratistaId;
  final String tipoEquipo; // 'ONT', 'MESH', 'STB'
  final String serie;
  EstadoEquipoSeriado estado;
  String? otIdInstalado; // si está instalado, en qué OT (id de OrdenTrabajo)
  DateTime fechaIngreso; // cuándo entró a bodega/mochila del técnico

  EquipoSeriado({
    required this.id,
    required this.contratistaId,
    required this.tipoEquipo,
    required this.serie,
    this.estado = EstadoEquipoSeriado.disponible,
    this.otIdInstalado,
    DateTime? fechaIngreso,
  }) : fechaIngreso = fechaIngreso ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'contratistaId': contratistaId,
        'tipoEquipo': tipoEquipo,
        'serie': serie,
        'estado': estado.name,
        'otIdInstalado': otIdInstalado,
        'fechaIngreso': fechaIngreso.toIso8601String(),
      };

  factory EquipoSeriado.fromMap(Map<String, dynamic> map) => EquipoSeriado(
        id: map['id'] as String,
        contratistaId: map['contratistaId'] as String,
        tipoEquipo: map['tipoEquipo'] as String,
        serie: map['serie'] as String,
        estado: EstadoEquipoSeriado.values
            .firstWhere((e) => e.name == map['estado']),
        otIdInstalado: map['otIdInstalado'] as String?,
        fechaIngreso: DateTime.parse(map['fechaIngreso'] as String),
      );
}

/// Herramienta entregada una sola vez al técnico, sujeta a chequeo
/// mensual (no se consume ni se descuenta por instalación, a diferencia
/// de los materiales).
class Herramienta {
  final String id;
  final String contratistaId;
  final String nombre;
  String estado; // texto libre: 'OK', 'Falta', 'Dañada', etc.
  DateTime? ultimoChequeo;

  Herramienta({
    required this.id,
    required this.contratistaId,
    required this.nombre,
    this.estado = 'OK',
    this.ultimoChequeo,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'contratistaId': contratistaId,
        'nombre': nombre,
        'estado': estado,
        'ultimoChequeo': ultimoChequeo?.toIso8601String(),
      };

  factory Herramienta.fromMap(Map<String, dynamic> map) => Herramienta(
        id: map['id'] as String,
        contratistaId: map['contratistaId'] as String,
        nombre: map['nombre'] as String,
        estado: map['estado'] as String,
        ultimoChequeo: map['ultimoChequeo'] == null
            ? null
            : DateTime.parse(map['ultimoChequeo'] as String),
      );
}

/// Lista de materiales típicos vista en la hoja de despacho real de CARSO
/// (foto del 21/06/2026), para precargar nombres/unidades conocidas al
/// crear un artículo nuevo. El técnico ajusta cantidad y stock mínimo.
const List<Map<String, String>> materialesConocidosCarso = [
  {'codigo': '1022562', 'nombre': 'ACOPLE PARA CABLE DE DERIVACION', 'unidad': 'UD'},
  {'codigo': '1007878', 'nombre': 'CABLE OPTICO MOAVD 1 FIBRA', 'unidad': 'M'},
  {'codigo': '1013950', 'nombre': 'AMARRA PLASTICAS NEGRAS 8"', 'unidad': 'U'},
  {'codigo': '1027925', 'nombre': 'CABLE UTP CAT5 P/ INTERIORES', 'unidad': 'MTS'},
  {'codigo': '1004074', 'nombre': 'CONECTOR RJ45 CATEGORIA 5', 'unidad': 'U'},
  {'codigo': '1005388', 'nombre': 'CONECTOR SIN HERRAMIENTA SC/APC', 'unidad': 'UD'},
  {'codigo': '1023835', 'nombre': 'ARGOLLA DE POLICARBONATO', 'unidad': 'U'},
  {'codigo': '1023944', 'nombre': 'TORNILLO DE OJO PARA TECHO', 'unidad': 'UN'},
];

/// Materiales consumibles típicos de la hoja de COLSAGO (foto del
/// 22/06/2026, "RECIBO DE ENTREGA DE MATERIALES"). Estos NO llevan
/// número de serie — se controlan por cantidad. Los equipos con serie
/// de esa misma hoja (ONT, MESH, STB) no van aquí: se cargan como
/// EquipoSeriado, uno por cada serie física leída del recibo.
const List<Map<String, String>> materialesConocidosColsago = [
  {'codigo': '', 'nombre': 'TORNILLO DE OJO', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'CONECTORES RJ 45', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'CONEC/ SIN HERRAMIENTAS', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'CABLE OPTICO FIBRA', 'unidad': 'M'},
  {'codigo': '', 'nombre': 'TENSORES', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'AMARRAS', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'CINTA DYMO', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'TAPE', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'ARGOLLA', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'CLICK', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'CABLE UTP', 'unidad': 'M'},
  {'codigo': '', 'nombre': 'ACOPLES', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'MAHA DEDOS', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'HERRAJE SUSPENSIÓN', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'ALCOHOL (TOALLAS)', 'unidad': 'UN'},
  {'codigo': '', 'nombre': 'MULTISWICH', 'unidad': 'UN'},
];

/// Tipos de equipo seriado conocidos (aparecen en la columna SERIES de
/// la hoja de COLSAGO: MESH, ONT, STBS/STB). Útil para el OCR y para
/// los selectores de la UI.
const List<String> tiposEquipoSeriadoConocidos = ['ONT', 'MESH', 'STB'];
