// lib/models/contratista.dart
//
// Modelo de Contratista. La app soporta múltiples contratistas en
// paralelo (ej. CARSO, COLSAGO, y cualquier contrata futura), bajo los
// que Roney trabaja como técnico instalador de Claro.
//
// FASE 3 (26/06/2026): CORRECCIÓN sobre Fase 1. En Fase 1 se quitó el
// campo de vigencia de tarifario de Contratista porque CARSO y COLSAGO
// resultaron compartir los mismos montos en el Excel real — pero eso
// fue una coincidencia de esos dos contratistas, no una regla general.
// Roney aclaró que una contrata futura podría tener su propio
// tarifario distinto, así que cada Contratista es un "árbol"
// independiente: su propio tarifario (ver tarifa.dart), su propio
// inventario, sus propios equipos seriados, sus propias OTs. Por eso
// tarifarioVigenteDesde vuelve a vivir aquí, una fecha por contratista,
// no una sola fecha global compartida.
//
// El contratista de cada OT importa para:
//   1. Elegir su tarifario correcto (tarifarioDe(contratistaId)).
//   2. A nombre de quién se factura (razón social, cédula jurídica).
//   3. Filtrar/agrupar reportes, inventario y equipos por separado.

class Contratista {
  final String id; // ej. 'carso', 'colsago'
  final String nombre; // ej. 'CARSO', 'COLSAGO COMM S.A.'
  final String razonSocial; // nombre legal completo, para facturación
  final String? cedulaJuridica;
  DateTime tarifarioVigenteDesde; // última actualización del tarifario DE ESTE contratista
  bool activo;

  Contratista({
    required this.id,
    required this.nombre,
    required this.razonSocial,
    this.cedulaJuridica,
    DateTime? tarifarioVigenteDesde,
    this.activo = true,
  }) : tarifarioVigenteDesde = tarifarioVigenteDesde ?? DateTime(2026, 1, 1);

  Map<String, dynamic> toMap() => {
        'id': id,
        'nombre': nombre,
        'razonSocial': razonSocial,
        'cedulaJuridica': cedulaJuridica,
        'tarifarioVigenteDesde': tarifarioVigenteDesde.toIso8601String(),
        'activo': activo ? 1 : 0,
      };

  factory Contratista.fromMap(Map<String, dynamic> map) => Contratista(
        id: map['id'] as String,
        nombre: map['nombre'] as String,
        razonSocial: map['razonSocial'] as String,
        cedulaJuridica: map['cedulaJuridica'] as String?,
        // Compatibilidad con filas guardadas en Fase 1-2 (sin esta
        // columna, cuando el tarifario era único y compartido).
        tarifarioVigenteDesde: map['tarifarioVigenteDesde'] == null
            ? DateTime(2026, 1, 1)
            : DateTime.parse(map['tarifarioVigenteDesde'] as String),
        activo: (map['activo'] as int) == 1,
      );
}

/// Contratistas conocidos al momento de crear la app. El técnico puede
/// agregar más desde la pantalla "Agregar contratista" si en el futuro
/// trabaja con otra contrata.
/// IMPORTANTE: las razones sociales y cédulas jurídicas son provisionales
/// — Roney debe confirmarlas/corregirlas, ya que son datos que aparecen
/// en cada factura.
final List<Contratista> contratistasIniciales = [
  Contratista(
    id: 'carso',
    nombre: 'CARSO',
    razonSocial: 'CARSO (pendiente confirmar razón social exacta)',
  ),
  Contratista(
    id: 'colsago',
    nombre: 'COLSAGO',
    razonSocial: 'COLSAGO COMM S.A.',
  ),
];
