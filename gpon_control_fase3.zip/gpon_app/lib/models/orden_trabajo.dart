// lib/models/orden_trabajo.dart
//
// Modelo de Orden de Trabajo (OT) y su parser desde texto copiado
// al portapapeles desde la app de despacho (Oracle).
//
// Formato real observado (capturas de pantalla, 21/06/2026):
//
//   Orden de Trabajo
//   CW_EOC200001196500967
//
//   Orden de Trabajo
//   CW_EOC200001196500967
//
//   Canal de Venta
//   Masivo
//
//   Nombre
//   JULIA MIGDALIA GARCIA
//
//   Estado
//   en ruta
//
//   Tipo OT
//   Instalación
//
//   Subtipo
//   Instalacion Internet (DGPON)+TV (GPON)
//
//   Plan
//   STB[4],Internet,Repetidor[0]
//
//   Etapa Orden
//   INSTALL
//
//   Número de Solicitud
//   200001196500967
//
//   Número Facturación
//   1556540
//
//   Dir
//   De soda patri 60 mts sur casa a mano izquierda SAN JOSE| CURRIDABAT| GRANADILLA
//
// Nota: el campo "Orden de Trabajo" aparece duplicado en el texto real
// (se ve dos veces seguidas en la captura). El parser solo necesita la
// primera coincidencia.
//
// ---------------------------------------------------------------------
// FASE 1 (25/06/2026): formato extendido confirmado con una OT ya
// completada ("Detalles de actividad"). Trae todos los campos de
// arriba más una sección final "Log Equipos" / "Historial de logs"
// con líneas de texto libre, una por evento, con este patrón:
//
//   Se ha instalado el equipo STB ZTEATV45503401471 exitosamente
//   Se ha desinstalado el equipo STB ZTEATV45503402402
//   Se ha instalado el equipo STB ZTEATV45503401407 exitosamente
//   Se ha instalado el equipo ONT 4857544374B9D1B4
//
// Reglas observadas:
//   - El verbo es "instalado" o "desinstalado".
//   - El tipo de equipo (STB, ONT, MESH, etc.) es la palabra justo antes
//     de la serie.
//   - La serie es alfanumérica, sin espacios.
//   - El sufijo "exitosamente" es opcional y se ignora.
//   - Una misma serie puede aparecer más de una vez en el mismo log
//     (ej. desinstalada y luego reinstalada en la misma visita, cuando
//     el técnico detecta un equipo defectuoso de fábrica y lo cambia
//     en sitio). El parser conserva CADA evento en orden, no deduplica,
//     porque el orden cronológico es lo que permite distinguir ese caso
//     de una avería real (ver EventoEquipo).
//
// También se observan campos adicionales que el parser anterior no
// capturaba: Teléfono de Contacto/Casa/Trabajo, Categorización, Tipo de
// Orden, Tipo de Servicio, Comentario, Equipos Internet/Requeridos/
// Instalados, Cantidad Repetidores, Inicio-Fin, Ventana Entrega,
// Duración. Se agregan como campos opcionales (String?) para no romper
// OTs ya guardadas en versiones previas de la app, que no los tendrán.

enum EstadoOT { pendiente, enRuta, instalado, liquidado }

/// Tipo de evento de equipo detectado en el Log de Equipos de Oracle.
enum TipoEventoEquipo { instalado, desinstalado }

/// Un evento individual del Log de Equipos: un equipo que se instaló o
/// desinstaló durante la visita, en el orden en que aparece en el texto.
///
/// Cuando un técnico revisa una OT con series desinstaladas, la app debe
/// preguntar caso por caso si esa serie vuelve al inventario disponible
/// (cambio en sitio por defecto de fábrica, el equipo no se usó de
/// verdad) o se marca como dañada (avería real, no vuelve a stock hasta
/// que bodega la reciba de regreso). Ese resultado se guarda en
/// `resolucion` una vez que el técnico responde; null mientras está
/// pendiente de revisar.
class EventoEquipo {
  final TipoEventoEquipo tipo;
  final String tipoEquipo; // 'STB', 'ONT', 'MESH', etc.
  final String serie;
  ResolucionDesinstalacion? resolucion; // solo relevante si tipo == desinstalado

  EventoEquipo({
    required this.tipo,
    required this.tipoEquipo,
    required this.serie,
    this.resolucion,
  });

  Map<String, dynamic> toMap() => {
        'tipo': tipo.name,
        'tipoEquipo': tipoEquipo,
        'serie': serie,
        'resolucion': resolucion?.name,
      };

  factory EventoEquipo.fromMap(Map<String, dynamic> map) => EventoEquipo(
        tipo: TipoEventoEquipo.values.firstWhere((t) => t.name == map['tipo']),
        tipoEquipo: map['tipoEquipo'] as String,
        serie: map['serie'] as String,
        resolucion: map['resolucion'] == null
            ? null
            : ResolucionDesinstalacion.values
                .firstWhere((r) => r.name == map['resolucion']),
      );
}

/// Cómo se resuelve una serie que aparece "desinstalada" en el log.
enum ResolucionDesinstalacion {
  vuelveAInventario, // cambio en sitio, el equipo no estaba realmente averiado
  danado, // avería real, sale de circulación hasta devolverlo a bodega
}

class OrdenTrabajo {
  final String id; // usamos el numero de OT (CW_EOC...) como id
  final String numeroOT;
  final String contratistaId; // 'carso' | 'colsago' | ... (Fase 1)
  final String canalVenta;
  final String nombreCliente;
  String estadoTexto; // texto crudo tal cual viene de la OT ("en ruta", etc.)
  EstadoOT estadoFlujo; // estado dentro del flujo de la app
  final String tipoOT;
  final String subtipo;
  final String plan;
  final String etapaOrden;
  final String numeroSolicitud;
  final String numeroFacturacion;
  final String direccion;
  final DateTime fechaCreacion;

  // Campos adicionales del formato extendido (Fase 1, 25/06/2026).
  // Todos opcionales: una OT capturada con el parser anterior no los
  // tendrá, y eso es válido.
  final String? telefonoContacto;
  final String? categorizacion;
  final String? tipoOrden; // ej. 'INT'
  final String? tipoServicio; // ej. 'POCRGM_300MbpsSM_AvanzadoPL_C'
  final String? inicioFin; // texto crudo, ej. '15:13 - 17:17'
  final String? duracion; // texto crudo, ej. '2 Horas 4 min'

  // Log de equipos extraído de la sección "Log Equipos" / "Historial
  // de logs". Vacío si la OT no trae esa sección (ej. OT capturada
  // antes de que el técnico llegara a esa etapa).
  List<EventoEquipo> logEquipos;

  // Datos que se completan en la app, no vienen del texto pegado:
  String? tarifaBaseId; // cuál tarifa de instalación de abonado aplica
  List<MaterialConsumido> materialesConsumidos;
  List<AdicionalFacturado> adicionalesFacturados;

  OrdenTrabajo({
    required this.id,
    required this.numeroOT,
    String? contratistaId,
    required this.canalVenta,
    required this.nombreCliente,
    required this.estadoTexto,
    required this.estadoFlujo,
    required this.tipoOT,
    required this.subtipo,
    required this.plan,
    required this.etapaOrden,
    required this.numeroSolicitud,
    required this.numeroFacturacion,
    required this.direccion,
    required this.fechaCreacion,
    this.telefonoContacto,
    this.categorizacion,
    this.tipoOrden,
    this.tipoServicio,
    this.inicioFin,
    this.duracion,
    List<EventoEquipo>? logEquipos,
    this.tarifaBaseId,
    List<MaterialConsumido>? materialesConsumidos,
    List<AdicionalFacturado>? adicionalesFacturados,
  })  : contratistaId = contratistaId ?? 'carso',
        logEquipos = logEquipos ?? [],
        materialesConsumidos = materialesConsumidos ?? [],
        adicionalesFacturados = adicionalesFacturados ?? [];

  Map<String, dynamic> toMap() => {
        'id': id,
        'numeroOT': numeroOT,
        'contratistaId': contratistaId,
        'canalVenta': canalVenta,
        'nombreCliente': nombreCliente,
        'estadoTexto': estadoTexto,
        'estadoFlujo': estadoFlujo.name,
        'tipoOT': tipoOT,
        'subtipo': subtipo,
        'plan': plan,
        'etapaOrden': etapaOrden,
        'numeroSolicitud': numeroSolicitud,
        'numeroFacturacion': numeroFacturacion,
        'direccion': direccion,
        'fechaCreacion': fechaCreacion.toIso8601String(),
        'telefonoContacto': telefonoContacto,
        'categorizacion': categorizacion,
        'tipoOrden': tipoOrden,
        'tipoServicio': tipoServicio,
        'inicioFin': inicioFin,
        'duracion': duracion,
        'tarifaBaseId': tarifaBaseId,
      };

  factory OrdenTrabajo.fromMap(Map<String, dynamic> map) => OrdenTrabajo(
        id: map['id'] as String,
        numeroOT: map['numeroOT'] as String,
        // Compatibilidad con OTs guardadas antes de Fase 1: se asumen
        // de CARSO, que era el único contratista en ese momento.
        contratistaId: (map['contratistaId'] as String?) ?? 'carso',
        canalVenta: map['canalVenta'] as String,
        nombreCliente: map['nombreCliente'] as String,
        estadoTexto: map['estadoTexto'] as String,
        estadoFlujo:
            EstadoOT.values.firstWhere((e) => e.name == map['estadoFlujo']),
        tipoOT: map['tipoOT'] as String,
        subtipo: map['subtipo'] as String,
        plan: map['plan'] as String,
        etapaOrden: map['etapaOrden'] as String,
        numeroSolicitud: map['numeroSolicitud'] as String,
        numeroFacturacion: map['numeroFacturacion'] as String,
        direccion: map['direccion'] as String,
        fechaCreacion: DateTime.parse(map['fechaCreacion'] as String),
        telefonoContacto: map['telefonoContacto'] as String?,
        categorizacion: map['categorizacion'] as String?,
        tipoOrden: map['tipoOrden'] as String?,
        tipoServicio: map['tipoServicio'] as String?,
        inicioFin: map['inicioFin'] as String?,
        duracion: map['duracion'] as String?,
        tarifaBaseId: map['tarifaBaseId'] as String?,
      );
}

class MaterialConsumido {
  final String codigoArticulo;
  final String nombreArticulo;
  final double cantidad;
  final String unidad;

  MaterialConsumido({
    required this.codigoArticulo,
    required this.nombreArticulo,
    required this.cantidad,
    required this.unidad,
  });

  Map<String, dynamic> toMap() => {
        'codigoArticulo': codigoArticulo,
        'nombreArticulo': nombreArticulo,
        'cantidad': cantidad,
        'unidad': unidad,
      };

  factory MaterialConsumido.fromMap(Map<String, dynamic> map) =>
      MaterialConsumido(
        codigoArticulo: map['codigoArticulo'] as String,
        nombreArticulo: map['nombreArticulo'] as String,
        cantidad: (map['cantidad'] as num).toDouble(),
        unidad: map['unidad'] as String,
      );
}

class AdicionalFacturado {
  final String tarifaId;
  final double cantidad; // para metros, puede ser fraccionario
  final double subtotal;

  AdicionalFacturado({
    required this.tarifaId,
    required this.cantidad,
    required this.subtotal,
  });

  Map<String, dynamic> toMap() => {
        'tarifaId': tarifaId,
        'cantidad': cantidad,
        'subtotal': subtotal,
      };

  factory AdicionalFacturado.fromMap(Map<String, dynamic> map) =>
      AdicionalFacturado(
        tarifaId: map['tarifaId'] as String,
        cantidad: (map['cantidad'] as num).toDouble(),
        subtotal: (map['subtotal'] as num).toDouble(),
      );
}

/// Parser de texto de OT copiado al portapapeles.
///
/// Estrategia: en vez de depender de saltos de línea exactos (que pueden
/// variar según el celular/app), se busca cada etiqueta conocida y se
/// captura el contenido hasta la siguiente etiqueta conocida o el final
/// del texto. Esto es más robusto que asumir un orden de líneas fijo.
class OTParser {
  // Etiquetas en el orden en que aparecen en el texto real.
  //
  // IMPORTANTE: el campo 'Dir' es texto libre y puede ser largo; para
  // que el parser sepa dónde termina (y no se "coma" los campos que
  // vienen después, como Inicio-Fin o el Log de Equipos), TODAS las
  // etiquetas que pueden aparecer después de 'Dir' en el formato
  // extendido (confirmado 25/06/2026) deben estar en esta lista, aunque
  // el modelo OrdenTrabajo no las use todas todavía.
  static const List<String> _etiquetas = [
    'Orden de Trabajo',
    'Canal de Venta',
    'Nombre',
    'Estado',
    'Tipo OT',
    'Subtipo',
    'Plan',
    'Etapa Orden',
    'Número de Solicitud',
    'Numero de Solicitud',
    'Número Facturación',
    'Numero Facturacion',
    'Dir',
    'Inicio - Fin',
    'Ventana Entrega',
    'Duración',
    'Duracion',
    'Teléfono de Contacto',
    'Telefono de Contacto',
    'Teléfono Contacto Casa',
    'Telefono Contacto Casa',
    'Teléfono de Casa',
    'Telefono de Casa',
    'Teléfono de Trabajo',
    'Telefono de Trabajo',
    'Categorización',
    'Categorizacion',
    'Tipo de Orden',
    'Tipo de Servicio',
    'Comentario',
    'Equipos Internet',
    'Equipos Internet Requeridos',
    'Cantidad Repetidores',
    'Repetidores Requeridos',
    'Equipos Requeridos',
    'Equipos Instalados',
    'Log Equipos',
    'Historial de logs',
  ];

  /// Intenta parsear el texto. Devuelve null si no encuentra al menos
  /// el número de OT (campo mínimo indispensable).
  ///
  /// [contratistaId] permite indicar de qué contratista es la OT (ej.
  /// 'carso' o 'colsago'). El texto de Oracle no identifica de forma
  /// confiable el contratista, así que por ahora se recibe como
  /// parámetro explícito (lo elige el técnico en la UI antes de pegar
  /// el texto, o se deja el valor por defecto 'carso' y se corrige
  /// después si hace falta).
  static OrdenTrabajo? parse(String texto, {String contratistaId = 'carso'}) {
    final campos = _extraerCampos(texto);

    final numeroOT = campos['Orden de Trabajo'];
    if (numeroOT == null || numeroOT.isEmpty) return null;

    final direccionCruda = campos['Dir'] ?? '';

    // NOTA: 'Log Equipos' y 'Historial de logs' aparecen como dos
    // encabezados consecutivos en el texto real (uno es subtítulo del
    // otro); el contenido del log queda asociado a 'Historial de logs'
    // (la última etiqueta antes del texto real), mientras que 'Log
    // Equipos' captura un valor vacío. Por eso no basta con `??` (que
    // solo cae al fallback si es null, no si es ''): hay que preferir
    // el que tenga contenido real.
    final bloqueLogA = campos['Log Equipos'] ?? '';
    final bloqueLogB = campos['Historial de logs'] ?? '';
    final bloqueLog = bloqueLogB.isNotEmpty ? bloqueLogB : bloqueLogA;
    final logEquipos = _extraerLogEquipos(bloqueLog);

    return OrdenTrabajo(
      id: numeroOT,
      numeroOT: numeroOT,
      contratistaId: contratistaId,
      canalVenta: campos['Canal de Venta'] ?? '',
      nombreCliente: campos['Nombre'] ?? '',
      estadoTexto: campos['Estado'] ?? '',
      estadoFlujo: _mapearEstadoInicial(campos['Estado'] ?? ''),
      tipoOT: campos['Tipo OT'] ?? '',
      subtipo: campos['Subtipo'] ?? '',
      plan: campos['Plan'] ?? '',
      etapaOrden: campos['Etapa Orden'] ?? '',
      numeroSolicitud:
          campos['Número de Solicitud'] ?? campos['Numero de Solicitud'] ?? '',
      numeroFacturacion:
          campos['Número Facturación'] ?? campos['Numero Facturacion'] ?? '',
      direccion: direccionCruda.trim(),
      fechaCreacion: DateTime.now(),
      telefonoContacto: campos['Teléfono de Contacto'] ??
          campos['Telefono de Contacto'],
      categorizacion: campos['Categorización'] ?? campos['Categorizacion'],
      tipoOrden: campos['Tipo de Orden'],
      tipoServicio: campos['Tipo de Servicio'],
      inicioFin: campos['Inicio - Fin'],
      duracion: campos['Duración'] ?? campos['Duracion'],
      logEquipos: logEquipos,
    );
  }

  /// Extrae los eventos de instalación/desinstalación del bloque de
  /// texto del Log de Equipos. Conserva el orden cronológico y NO
  /// deduplica series repetidas: una misma serie puede aparecer varias
  /// veces (desinstalada y reinstalada en la misma visita), y ese orden
  /// es justamente lo que la app necesita para que el técnico decida
  /// después si fue un cambio en sitio o una avería real.
  ///
  /// Formato de cada línea esperado:
  ///   "Se ha instalado el equipo STB ZTEATV45503401471 exitosamente"
  ///   "Se ha desinstalado el equipo STB ZTEATV45503402402"
  ///   "Se ha instalado el equipo ONT 4857544374B9D1B4"
  static List<EventoEquipo> _extraerLogEquipos(String bloque) {
    if (bloque.trim().isEmpty) return [];

    final patron = RegExp(
      r'Se\s+ha\s+(instalado|desinstalado)\s+el\s+equipo\s+(\S+)\s+(\S+)',
      caseSensitive: false,
    );

    final eventos = <EventoEquipo>[];
    for (final match in patron.allMatches(bloque)) {
      final verbo = match.group(1)!.toLowerCase();
      final tipoEquipo = match.group(2)!;
      final serie = match.group(3)!;

      eventos.add(EventoEquipo(
        tipo: verbo == 'instalado'
            ? TipoEventoEquipo.instalado
            : TipoEventoEquipo.desinstalado,
        tipoEquipo: tipoEquipo,
        serie: serie,
      ));
    }
    return eventos;
  }

  static EstadoOT _mapearEstadoInicial(String estadoTexto) {
    final t = estadoTexto.toLowerCase().trim();
    if (t.contains('ruta')) return EstadoOT.enRuta;
    if (t.contains('instal')) return EstadoOT.instalado;
    if (t.contains('liquid')) return EstadoOT.liquidado;
    return EstadoOT.pendiente;
  }

  /// Extrae pares etiqueta -> valor del texto crudo.
  static Map<String, String> _extraerCampos(String texto) {
    final resultado = <String, String>{};

    final ocurrencias = <_Ocurrencia>[];
    for (final etiqueta in _etiquetas) {
      final patron = RegExp(
        r'(?:^|\n)\s*' + RegExp.escape(etiqueta) + r'\s*(?:\n|$)',
        caseSensitive: false,
        multiLine: true,
      );
      for (final match in patron.allMatches(texto)) {
        ocurrencias.add(_Ocurrencia(etiqueta, match.start, match.end));
      }
    }

    ocurrencias.sort((a, b) => a.inicioEtiqueta.compareTo(b.inicioEtiqueta));

    for (int i = 0; i < ocurrencias.length; i++) {
      final actual = ocurrencias[i];
      final inicioValor = actual.finEtiqueta;
      final finValor = (i + 1 < ocurrencias.length)
          ? ocurrencias[i + 1].inicioEtiqueta
          : texto.length;

      final valor = texto
          .substring(inicioValor, finValor.clamp(inicioValor, texto.length))
          .trim();

      if (!resultado.containsKey(actual.etiqueta) ||
          resultado[actual.etiqueta]!.isEmpty) {
        resultado[actual.etiqueta] = valor;
      }
    }

    return resultado;
  }
}

class _Ocurrencia {
  final String etiqueta;
  final int inicioEtiqueta;
  final int finEtiqueta;
  _Ocurrencia(this.etiqueta, this.inicioEtiqueta, this.finEtiqueta);
}
