package com.roneyrigg.gponcontrol

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
