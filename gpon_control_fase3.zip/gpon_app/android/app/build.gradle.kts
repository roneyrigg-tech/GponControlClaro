plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.roneyrigg.gponcontrol"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        // Identificador único de la app. Si en el futuro se publica en
        // Google Play, este valor no se puede cambiar después.
        applicationId = "com.roneyrigg.gponcontrol"
        // FASE 2 (25/06/2026): se fija minSdk=21 explícito (en vez de
        // depender solo del default de Flutter) porque
        // google_mlkit_text_recognition lo requiere como mínimo.
        minSdk = maxOf(flutter.minSdkVersion, 21)
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        multiDexEnabled = true
    }

    buildTypes {
        release {
            // Por ahora se firma con la llave de debug para poder
            // generar un APK instalable rápidamente. Para publicar en
            // Play Store habría que configurar una keystore propia
            // (ver android/key.properties.example).
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
        }
    }
}

flutter {
    source = "../.."
}
